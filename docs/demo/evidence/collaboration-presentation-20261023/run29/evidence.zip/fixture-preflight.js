// Shipped handlers with existing mechanical DOM and frozen DTO replies; no HTTP/Chrome.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),cp=require('child_process');
const baseline=cp.execFileSync('git',['show','aa6b2fb7e92853ea4b22d163260b309bb7992f74:src/parkweave/web.html'],{encoding:'utf8'});
const support=fs.readFileSync('tests/ordinary_case_goal_record_pack_html.js','utf8').split('const until=')[0];
const old=JSON.parse(fs.readFileSync('docs/F2/evidence/no-model-tail-20261022/run21/result.json','utf8'));
const role=JSON.parse(fs.readFileSync('docs/F2/evidence/again-role-readback-20261022/run23/result.json','utf8')).fresh_roles[0];
const goals=old.exports[0].goal_results,TXT=fs.readFileSync('docs/F2/evidence/no-model-tail-20261022/run21/p5-unverified-case-record-pack.txt','utf8');
let calls=[];
function page(before){
 const adapted={...fs,readFileSync:(name,...args)=>before&&name==='src/parkweave/web.html'?baseline:fs.readFileSync(name,...args)};
 const scope={require:n=>n==='fs'?adapted:require(n),console:{log(){},error(){}},process,URL,URLSearchParams,Blob,TextEncoder,setTimeout,clearTimeout,
 fetch:async(url,options={})=>{const path=new URL(url).pathname;assert.strictEqual(options.method||'GET','GET');calls.push(path);let body;
 if(path==='/api/run-access/status')body={enabled:false,read_available:false,scope:'PRESENTATION_REPLAY_DISABLED'};
 else if(path==='/api/preparations')body={role:'enterprise_operator',items:role.preparations.map(x=>x.preparation)};
 else if(path==='/api/preparations/'+goals.preparation_id+'/goal-results')body=goals;
 else throw Error('Unexpected fixture path '+path);
 return {status:200,ok:true,json:async()=>structuredClone(body)};}};
 return vm.runInNewContext(support+`;page({base:'http://127.0.0.1',token:'VIEW_REPLAY_NO_AUTHORITY'},{},[],{});`,scope);
}
async function main(){const out=[];
 for(const before of [true,false]){
  const p=page(before);await p.$('prep-list').onclick();assert.strictEqual(p.$('prep-items').children.length,2);p.context.fixture=old.accepted_dispatch;p.run('renderDispatch(fixture)');assert.strictEqual(p.run('JSON.stringify(dispatchView)'),JSON.stringify(old.accepted_dispatch));assert.strictEqual(p.$('dispatch-receipt').hidden,false);
  p.context.fixture=old.acknowledged_receipt;p.run('renderReceipt(fixture)');assert.strictEqual(p.run('JSON.stringify(receiptView)'),JSON.stringify(old.acknowledged_receipt));assert(p.$('receipt-ack').disabled&&p.$('receipt-correct').disabled&&!p.$('receipt-reopen').disabled);
  p.context.fixture=goals;
  await p.run(`(async()=>{clearPreparation();clearDispatch();clearReceipts();clearServiceCasePlan();servicePlanId=fixture.preparation_id;servicePlanView={role:'enterprise_operator',read_only:false,case_id:fixture.case_id,run_id:fixture.run_id,plan_id:fixture.plan_id,revision:fixture.plan_revision,preparation_revision:fixture.preparation_revision,request_revision:fixture.request_revision,actor_ref:await coldDigest({actor_id:fixture.actor_id})};await readGoalResults();})()`);
  assert.strictEqual(p.run('JSON.stringify(goalResultView)'),JSON.stringify(goals),p.$('goal-results-error').textContent);assert(p.$('case-record-pack-download').disabled);
  await p.run("caseRecordPackAction('generate')");assert.strictEqual(p.$('case-record-pack-text').value,TXT,p.$('case-record-pack-status').textContent);assert(!p.$('case-record-pack-download').disabled);
  out.push({variant:before?'before':'after',original_dispatch_and_receipt_DTOs_preserved:true,receipt_ACK_and_correction_disabled_reopen_enabled:true,goal_DTO_preserved:true,TXT_bytes:Buffer.byteLength(TXT),TXT_identical:true});
 }
 console.log(JSON.stringify({status:'FROZEN_FIXTURE_INTERFACES_PASS_NOT_BROWSER_OR_AUTHORIZATION',variants:out,controlled_GET_replies:calls.length,actual_HTTP:0,business_POSTs:0,browser_runs:0,model_calls:0},null,2));
}
main().then(()=>process.exit(0)).catch(e=>{console.error(e.stack);process.exit(1)});
