"""Offline verification of the extracted run29 evidence bundle; no execution."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
from io import BytesIO
import json,struct
p=Path(__file__).parent
read=lambda n:json.loads((p/n).read_text())
digest=lambda n:sha256((p/n).read_bytes()).hexdigest()
manifest=dict(line.split('  ',1)[::-1] for line in (p/'checksums.sha256').read_text().splitlines())
assert set(manifest)=={f.name for f in p.iterdir() if f.is_file() and f.name!='checksums.sha256'}
assert all(digest(n)==h for n,h in manifest.items())
run=read('run-api.json');job=read('job-api.json')['jobs'][0];a=read('artifact-metadata.json')['artifacts'][0]
source='6ba3459f51929a46128b656d6452c2db8efd3a6c'
assert run['id']==39886778975 and run['run_number']==29 and run['run_attempt']==1 and run['head_sha']==source and run['conclusion']=='success'
assert job['id']==120196678972 and job['conclusion']=='success' and all(s['conclusion']=='success' for s in job['steps'])
assert a['id']==12473141695 and a['digest']=='sha256:'+digest('artifact.zip')=='sha256:8ceffbad88b24d4a657fbf9b3998171b6e5141fa60e0229c9129aae85db8214c'
with ZipFile(p/'artifact.zip') as z:
    assert len(z.infolist())==9 and sum(i.file_size for i in z.infolist())==2104503<8388608
    assert all('/' not in n for n in z.namelist())
    pngs=[n for n in z.namelist() if n.endswith('.png')];assert len(pngs)==8
    r=json.loads(z.read('result.json'))
    for row in read('visual-review.json')['screenshots']:
        b=z.read(row['name']);assert sha256(b).hexdigest()==row['sha256'] and list(struct.unpack('>II',b[16:24]))==[row['width'],row['height']]
assert r['status']=='PASS' and r['stage']=='COMPLETE' and r['source_sha']==source and r['worker_final'] and not r['worker_output_truncated']
assert not any(r[k] for k in ('cleanup_errors','page_errors','violations','unexpected_GET','business_POSTs','real_model_calls','product_API','database'))
assert len(r['requests'])==len(r['browser_requests'])==20 and all(x['method']=='GET' for x in r['requests']+r['browser_requests'])
assert len(r['checks'])==len(r['font_observations'])==len(r['presentation_projections'])==16
assert all(x['documentWidth']==x['width'] for x in r['checks'])
for kind in ('collaboration','dispatch','receipt','goals-txt'):
    rows=[x for x in r['presentation_projections'] if x['component']==kind]
    assert len(rows)==4 and len({x['projection_sha256'] for x in rows})==1 and all(x['projection']==rows[0]['projection'] for x in rows)
assert len(r['TXT_replay'])==4 and all(x['bytes']==16500 and x['sha256']=='02c87cebbfa2c60737f6cfbfeb60628181241f2c5b5399433d4b13400cae9bdd' for x in r['TXT_replay'])
assert all(x['goal_state_colors'][-1]['state']=='WAITING_OUTPUT' for x in r['presentation_projections'] if x['component']=='goals-txt' and x['variant']=='after')
assert r['source_binding']['complete_script_identical'] and r['source_binding']['outside_CSS_and_seven_static_groups_identical']
assert r['installed_CJK_font']['rendering_observed'] and len(r['installed_CJK_font']['required_codepoints'])==684
o=r['owned_launch'];assert o['status']=='CLEANUP_CONFIRMED' and o['operation_status']=='PASS' and o['worker_returncode']==0 and o['bound_processes_exited'] and o['subtree_complete']
assert len(o['processes'])==7 and all(x['exited'] and x['ownership_basis'] for x in o['processes'])
assert not any(o[k] for k in ('errors','signals','remaining_children','remaining_private_session_members'))
assert r['browser_close']=='CLOSED' and r['listener_after_cleanup']=='REFUSED' and r['work_and_cleanup_seconds']<=90 and r['seconds']<=360
log=(p/'ci-original.log').read_bytes().decode();assert len(log)==641018 and len(log.encode())==675478 and digest('ci-original.log')=='1518a0b1f29f7e48101b81d2e00ded7895d338ecce7bc289bf6756000e687726'
rows=[s.partition('Z ')[2] for s in log.splitlines() if s.partition('Z ')[2].startswith('{"scope": "REAL_CHROME_ORIGINAL_PAGES_PRESENTATION_NO_BACKEND"')];assert len(rows)==1
v=json.loads(rows[0]);assert v['status']=='PENDING_FINALIZATION';v['status']=v.pop('observation_outcome');v.pop('terminal_result')
assert v=={k:v for k,v in r.items() if k not in ('seconds','seconds_scope')}
assert 'FINALIZATION_OUTPUT_CHECKPOINT' in log and 'upload aborted' not in log.lower()
assert read('actual-review.json')['status']=='LIMITED_ACK'
print(json.dumps({'status':'RUN29_ARCHIVE_CONSISTENT_NOT_NEW_EXECUTION','source_sha':source,'run':29,'attempt':1,'raw_ZIP_members':9,'component_projections':16,'same_GETs_observed_at_each_side':20,'business_POSTs':0,'complete_log_characters':len(log)}))
