"""Verify extracted run30 archive only; no browser, network or product actions."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json, struct
p = Path(__file__).parent
read = lambda n: json.loads((p/n).read_text())
digest = lambda n: sha256((p/n).read_bytes()).hexdigest()
manifest = dict(line.split('  ', 1)[::-1] for line in (p/'checksums.sha256').read_text().splitlines())
assert set(manifest) == {f.name for f in p.iterdir() if f.is_file() and f.name != 'checksums.sha256'}
assert all(digest(n) == h for n,h in manifest.items())
source = '921bf7022451dcef96347f7bab7c7367ef4c0990'
run = read('run-api.json'); job = read('job-api.json')['jobs'][0]; artifact = read('artifact-metadata.json')['artifacts'][0]
assert run['id'] == 39891361604 and run['run_number'] == 30 and run['run_attempt'] == 1
assert run['head_sha'] == source and run['conclusion'] == 'success'
assert job['id'] == 120211628924 and job['conclusion'] == 'success'
assert all(s['conclusion'] == 'success' for s in job['steps'])
assert artifact['id'] == 12474876627 and artifact['digest'] == 'sha256:' + digest('artifact.zip')
assert digest('artifact.zip') == 'a3418ecc9f1c8094fe1cbdc8912d3d865e91cafdb495e916d7380534b18aecda'
with ZipFile(p/'artifact.zip') as z:
    assert len(z.infolist()) == 9 and sum(i.file_size for i in z.infolist()) < 8388608
    assert all('/' not in n for n in z.namelist()) and len([n for n in z.namelist() if n.endswith('.png')]) == 8
    r = json.loads(z.read('result.json'))
    for row in read('visual-review.json')['screenshots']:
        b = z.read(row['name'])
        assert sha256(b).hexdigest() == row['sha256']
        assert list(struct.unpack('>II', b[16:24])) == [row['width'], row['height']]
assert r['status'] == 'PASS' and r['stage'] == 'COMPLETE' and r['source_sha'] == source
assert r['worker_final'] and not r['worker_output_truncated']
assert not any(r[k] for k in ('cleanup_errors','page_errors','violations','unexpected_GET','business_POSTs','real_model_calls','product_API','database'))
assert len(r['requests']) == len(r['browser_requests']) == 35
assert all(x['method'] == 'GET' for x in r['requests'] + r['browser_requests'])
assert len(r['checks']) == len(r['font_observations']) == 9
assert all(x['documentWidth'] == x['width'] for x in r['checks'])
assert len(r['indexes']) == 8 and len(r['loading']) == 4 and len(r['original_open_reads']) == 4
assert all(x['original_DTO_equal'] for x in r['original_open_reads'])
assert len(r['retained_receipt_reopen']) == 2 and len(r['feedback_faults']) == 17
for kind in ('dispatch','receipt'):
    for width in (1200,390):
        rows = [x for x in r['indexes'] if x['kind'] == kind and x['width'] == width]
        assert len(rows) == 2 and rows[0]['original_DTO'] == rows[1]['original_DTO']
        states = {x['state'] for x in r['feedback_faults'] if x['kind'] == kind and x['width'] == width}
        assert {'EMPTY','DENIED','READY','ERROR'} <= states
assert all(x['button_disabled'] and x['aria_busy'] for x in r['loading'])
assert r['source_binding']['all_other_HTML_and_business_script_identical']
assert r['installed_CJK_font']['rendering_observed'] and len(r['installed_CJK_font']['required_codepoints']) == 685
assert '--no-sandbox' not in r['chrome_arguments'] and 'adequately sandboxed' in r['sandbox_status']
owned = r['owned_launch']
assert owned['status'] == 'CLEANUP_CONFIRMED' and owned['operation_status'] == 'PASS'
assert owned['worker_returncode'] == 0 and owned['bound_processes_exited'] and owned['subtree_complete']
assert len(owned['processes']) == 8 and all(x['exited'] and x['ownership_basis'] for x in owned['processes'])
assert not any(owned[k] for k in ('errors','signals','remaining_children','remaining_private_session_members'))
assert r['browser_close'] == 'CLOSED' and r['listener_after_cleanup'] == 'REFUSED'
assert r['work_and_cleanup_seconds'] <= 90 and r['seconds'] <= 360
log = (p/'ci-original.log').read_text()
assert len(log) == 358611 and len(log.encode()) == 362721
assert digest('ci-original.log') == 'b53e80048a9c98ce0cddc3dd73c640ba9ae46df63cef176ecb496a298a0dc731'
rows = [s.partition('Z ')[2] for s in log.splitlines() if s.partition('Z ')[2].startswith('{"scope": "REAL_CHROME_ORIGINAL_PAGES_PRESENTATION_NO_BACKEND"')]
assert len(rows) == 1
v = json.loads(rows[0]); assert v['status'] == 'PENDING_FINALIZATION'
v['status'] = v.pop('observation_outcome'); v.pop('terminal_result')
assert v == {k:value for k,value in r.items() if k not in ('seconds','seconds_scope')}
assert 'FINALIZATION_OUTPUT_CHECKPOINT' in log and 'upload aborted' not in log.lower()
tests = read('targeted-results.json')
assert len(tests) == 8 and all(x['exit_code'] == 0 for x in tests)
assert read('source-publication-state.json')['published'] and read('source-publication-state.json')['pending'] is None
assert read('actual-review.json')['status'] == 'LIMITED_ACK'
print(json.dumps({'status':'RUN30_ARCHIVE_CONSISTENT_NOT_NEW_EXECUTION','source_sha':source,'run':30,'attempt':1,'raw_ZIP_members':9,'GETs_each_side_same_requests':35,'POSTs':0,'full_log_characters':len(log)}))
