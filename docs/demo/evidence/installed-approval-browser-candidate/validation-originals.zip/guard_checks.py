"""Deterministic candidate boundary regressions; no browser/CI/PG is started."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import json,tempfile,subprocess
from scripts import local_approval_installed_browser_once as m

passed=[]
def check(name,call):
 call();passed.append(name);print('PASS',name,flush=True)
def rejects(call,kind=AssertionError):
 try:call()
 except kind:return
 raise AssertionError('expected rejection')

def cumulative():
 b=m.Budget({})
 for _ in range(26):b.count('POST','/api/preparations','API_PREPARATION')
 for _ in range(8):b.count('POST','/api/preparations','BROWSER')
 for _ in range(3):b.count('POST','/api/preparations','NEGATIVE_AND_REPEAT')
 assert b.posts==37
 rejects(lambda:b.count('POST','/api/preparations','BROWSER'))
 for _ in range(360):b.count('GET','/api/read','BROWSER')
 rejects(lambda:b.count('GET','/api/read','BROWSER'))
check('one cumulative 37POST, phase and GET hard ceilings',cumulative)

class Route:
 def __init__(self,path,method='POST',key=None,action=None,origin='http://127.0.0.1:3333'):
  self.request=SimpleNamespace(url=origin+path,method=method,headers={} if key is None else {'idempotency-key':key},post_data_json={'action':action},post_data='{}')
  self.continued=False;self.aborted=False
 def continue_(self):self.continued=True
 def abort(self,*a):self.aborted=True

def keys():
 report=dict(origin='http://127.0.0.1:3333',violations=[]);b=m.Budget(report);path='/api/preparations/one/plan-approval/proposals';key='11111111-1111-4111-8111-111111111111'
 b.authorize(path);r=Route(path,key=key);b.route(r);assert r.continued
 r=Route('/api/preparations/one/plan-approval/recovery/'+key,'GET');b.route(r);assert r.continued
 b.authorize(path);r=Route(path,key=key);rejects(lambda:b.route(r));assert r.aborted
 b.expected=None;b.authorize(path);r=Route(path);rejects(lambda:b.route(r));assert r.aborted
 r=Route('/api/preparations/two/plan-approval/recovery/'+key,'GET');rejects(lambda:b.route(r));assert r.aborted
 b.expected=None;b.authorize(path);r=Route(path,key='22222222-2222-4222-8222-222222222222',origin='https://outside.invalid');rejects(lambda:b.route(r));assert r.aborted
check('original key uniqueness, missing key, crossCase recovery and origin rejection',keys)

class Child:
 pid=123456789
 def __init__(self,exit_code=0):self.done=False;self.code=exit_code
 def poll(self):return self.code if self.done else None
 @property
 def returncode(self):return self.poll()
 def terminate(self):self.done=True
 def wait(self,timeout):self.done=True;return self.code

def make_run():
 p=Path(tempfile.mkdtemp(prefix='parkweave-installed-guard-'));h=p/'harness';h.mkdir()
 r=SimpleNamespace(private=p,harness=h,python=Path('/unused/python'),state=p/'state',started=m.time.monotonic(),report={})
 r.budget=m.Budget(r.report);return r

def server_failure(primary,wrapper_exit=1,child_exit=0,primary_marker=True):
 run=make_run();child=Child(wrapper_exit)
 def popen(*a,**kw):
  kw['stdout'].write(json.dumps(dict(url='http://127.0.0.1:1',api_pid=2,readiness_attempts=1))+'\n');kw['stdout'].flush()
  observation=dict(children=[dict(exit_code=child_exit)],postgres_marker_absent=True,cleanup_errors=[])
  if primary_marker:observation['primary_error']={'error_type':'RuntimeError'}
  (run.harness/'owned-processes.json').write_text(json.dumps(observation))
  return child
 def invoke():
  with m.server(run):
   if primary:raise ValueError('original business failure retained')
 with patch.object(m.subprocess,'Popen',popen):
  if primary:
   try:invoke()
   except BaseExceptionGroup as error:
    assert isinstance(error.exceptions[0],ValueError) and isinstance(error.exceptions[1],AssertionError)
   else:raise AssertionError('missing primary+cleanup group')
  else:rejects(invoke)
 assert run.report['owned_API_listener_refused_after_stop'] and run.report['server_wrapper_exit']==wrapper_exit
def background_failures():
 server_failure(False)
 server_failure(False,wrapper_exit=0,child_exit=1,primary_marker=False)
check('stopped background or child failure cannot become PASS',background_failures)
check('business failure survives simultaneous cleanup/runtime failure',lambda:server_failure(True))

class SetupChild(Child):
 def __init__(self,unconfirmed):super().__init__(130);self.calls=0;self.unconfirmed=unconfirmed
 def wait(self,timeout):
  self.calls+=1
  if self.calls==1 or self.unconfirmed:raise subprocess.TimeoutExpired(['owned-setup'],timeout)
  return super().wait(timeout)

def setup_timeout(unconfirmed):
 run=make_run();child=SetupChild(unconfirmed)
 (run.harness/'setup-owned-processes.json').write_text(json.dumps(dict(state_dir=str(run.state),children=[dict(role='postgres',exit_code=0)],postgres_marker_absent=True,cleanup_errors=[],primary_error=dict(error_type='KeyboardInterrupt'))))
 with patch.object(m.subprocess,'Popen',return_value=child):
  rejects(lambda:m.setup_owned(run),BaseExceptionGroup if unconfirmed else subprocess.TimeoutExpired)
 assert child.calls==2 and child.done
 assert run.report['setup_stop_status']==('STOP_UNCONFIRMED' if unconfirmed else 'CONFIRMED')
check('setup timeout uses TERM and confirms PG cleanup while retaining timeout',lambda:setup_timeout(False))
check('setup stop timeout remains unconfirmed and preserves both errors',lambda:setup_timeout(True))
print(json.dumps(dict(status='PASS_GUARDS_ONLY_NOT_BROWSER',checks=len(passed),names=passed)),flush=True)
