from contextlib import redirect_stdout,redirect_stderr
from pathlib import Path
from types import SimpleNamespace
import json,os,sys,tempfile,uuid
import pytest,pgserver
from scripts.record_list_browser_once import observe_owned_fixture_pg,stop_owned_fixture_pg
mode=sys.argv[1];scratch=Path('/workspace/scratch/record-list-browser-20261022')
root=Path(tempfile.mkdtemp(prefix='parkweave-list-check-')) if mode=='good' else scratch/('rejected-owned-pg-'+uuid.uuid4().hex)
if mode!='good':root.mkdir(mode=0o700)
run=SimpleNamespace(report={},pg=None,pytest_root=root)
factory=pgserver.get_server
with (scratch/(mode+'-repair-pytest.log')).open('w') as stream,redirect_stdout(stream),redirect_stderr(stream):
    try:
        with observe_owned_fixture_pg(run):
            code=pytest.main(['-q','--tb=short','--basetemp',str(root/'pytest'),str(scratch/'api_smoke.py')])
        run.report['pytest_exit']=int(code)
    finally:stop_owned_fixture_pg(run)
run.report.update(mode=mode,factory_restored=pgserver.get_server is factory,root=str(root))
(scratch/(mode+'-repair-check.json')).write_text(json.dumps(run.report,indent=2)+'\n')
assert run.report['pytest_exit']==(0 if mode=='good' else 1)
assert run.report['owned_fixture_postgres_stopped'] and run.report['factory_restored']
if mode!='good':assert 'owned ephemeral test cluster directory evidence required' in (scratch/(mode+'-repair-pytest.log')).read_text()
print(json.dumps(run.report))
