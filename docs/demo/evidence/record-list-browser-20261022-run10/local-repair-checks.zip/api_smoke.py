"""One owned API preflight for the focused list browser's actual initial data."""
from conftest import pg,fixture
from test_preparation import preparation_fixture
from test_executor_receipts import receipt_fixture
from test_ordinary_case_steps import ordinary
from test_case_step_assignments import prepared,ok
from test_service_dispatches import offer,command
from ordinary_case_step_support import ordinary_api


def test_exact_two_current_preparation_records(ordinary,tmp_path):
    f,_=ordinary;records=[]
    for _ in range(2):
        p=prepared(f,label='SYNTHETIC 同名资料办理');d=ok(offer(f,p)[0],201);d=ok(command(f,d,'ACCEPT'))
        records.append(dict(preparation=p['preparation_id'],dispatch=d['dispatch_id'],receipt=d['receipt_step_id']))
    with ordinary_api(f,tmp_path/'api') as api:
        headers={'Authorization':'Bearer '+f[2]['fixture-a']}
        for kind,path in [('preparation','/api/preparations'),('dispatch','/api/service-dispatches'),('receipt','/api/executor-receipts')]:
            rows=api.get(path,headers=headers).json()['items']
            assert len(rows)==2 and rows[0]['goal']==rows[1]['goal']
            assert {row['id'] for row in rows}=={row[kind] for row in records}
            if kind!='dispatch':assert rows[0]['state']==rows[1]['state']
        for row in records:
            r=api.get('/api/executor-receipts/'+row['receipt'],headers=headers)
            assert r.status_code==200 and r.json()['step']['preparation_id']==row['preparation']
