"""Offline diagnostic fault injection. No browser, HTTP, DB or CI execution."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from contextlib import contextmanager
from hashlib import sha256
import ast, copy, io, json, os, subprocess, sys, tempfile, time, unittest
from scripts import full_guide_installed_browser_once as m

ROOT=Path('/workspace/ParkWeave');OUT=Path(__file__).parent
SOURCE='08e7f96c74dd313dcdac587f723f7eeb2dc08f5e'
SECRET='PRIVATE_SESSION_TOKEN_AND_PRIVATE_BUSINESS_TEXT'

def fixture(directory):
    now=time.monotonic();report=dict(source_sha=SOURCE,status='RUNNING',stage='PHASE_A_ORIGINAL_GUIDE',origin='http://127.0.0.1:1234',responses=[],violations=[])
    cfg=dict(report=report,phase='A',progress_path=str(directory/'partial.json'),progress_invocation='a'*32)
    run=SimpleNamespace(report=report,started=now,phase='A',ready=19,tokens={'enterprise':SECRET},diagnostic_actor='enterprise')
    p=m.Progress(run,cfg,now);run.progress=p
    return run,cfg,p

def request(method='POST'):
    return SimpleNamespace(method=method,url='http://127.0.0.1:1234/api/preparations/00000000-0000-4000-8000-000000000001/commands?secret='+SECRET,
        headers={'authorization':'Bearer '+SECRET,'idempotency-key':'00000000-0000-4000-8000-000000000002'},post_data_json={'action':'REVIEW','private':SECRET},post_data=SECRET)

class Checks(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='partial-offline-',dir=OUT);self.d=Path(self.tmp.name);self.run,self.cfg,self.p=fixture(self.d)
    def tearDown(self):self.tmp.cleanup()
    def read(self):return json.loads(Path(self.cfg['progress_path']).read_text())
    def rejects(self,fn):
        with self.assertRaises((AssertionError,ValueError,KeyError,TypeError)):fn()
    def test_01_interrupted_before_request(self):
        action=self.p.action('POST','#private-'+SECRET);action.__enter__()
        root=dict(status='FAIL',error='original primary',owned_cleanup={'exit':0})
        m.recover_progress(root,self.cfg)
        v=root['partial_progress']['A'];self.assertEqual(v['state'],'PARTIAL');self.assertEqual(v['outcome'],'UNKNOWN');self.assertFalse(v['worker_final'])
        self.assertEqual(v['in_flight_actions'],[1]);self.assertEqual(v['requests'],[]);self.assertIsNone(v['last_completed_action']);self.assertEqual(root['error'],'original primary');self.assertEqual(root['owned_cleanup'],{'exit':0})
        action.__exit__(None,None,None)
    def test_02_actual_route_without_response(self):
        req=request();req.url=req.url.split('?')[0];self.run.budget=m.Budget(self.run);self.run.budget.authorize(('/api/preparations/00000000-0000-4000-8000-000000000001/commands','REVIEW','enterprise'))
        route=SimpleNamespace(request=req,continue_=lambda:None,abort=lambda:None)
        with self.p.action('POST'):
            self.run.budget.route(route);v=self.read();row=v['requests'][0]
            self.assertEqual(row['state'],'CONTINUED');self.assertIsNone(row['response_status']);self.assertEqual(row['business_outcome'],'UNKNOWN');self.assertEqual(v['in_flight_actions'],[1])
        self.assertEqual(self.run.budget.posts,1)
    def test_03_response_headers_survive_body_error(self):
        req=request();self.p.request(req)
        response=SimpleNamespace(request=req,status=200,ok=True,url=req.url,json=lambda:(_ for _ in ()).throw(ValueError(SECRET)))
        walk=object.__new__(m.Walk);walk.run=self.run
        with self.assertRaisesRegex(ValueError,SECRET):walk.observed(response)
        row=self.read()['requests'][0];self.assertEqual(row['response_status'],200);self.assertEqual(row['body_state'],'READ_ERROR');self.assertEqual(row['business_outcome'],'UNKNOWN');self.assertNotIn(SECRET,Path(self.cfg['progress_path']).read_text())
    def test_04_normal_final_agrees_but_does_not_mark_server_success(self):
        with self.p.action('POST'):
            req=request();self.p.request(req);self.p.update_request(req,state='CONTINUED',response_status=201,body_state='OBSERVER_RETURNED')
        self.run.report.update(status='PASS',browser_worker_final='A');self.p.finish();root={'status':'RUNNING'}
        m.recover_progress(root,self.cfg,self.run.report)
        v=root['partial_progress']['A'];self.assertEqual(v['state'],'COMPLETE');self.assertTrue(v['worker_final']);self.assertEqual(v['last_completed_action'],1);self.assertEqual(v['requests'][0]['business_outcome'],'UNKNOWN');self.assertEqual(root['status'],'RUNNING')
    def test_05_checkpoint_failure_preserves_old_and_primary_error(self):
        old=Path(self.cfg['progress_path']).read_bytes()
        with patch.object(m,'progress_atomic',side_effect=OSError(SECRET)):
            with self.assertRaisesRegex(ValueError,'business primary'):
                with self.p.action('POST'):raise ValueError('business primary')
        self.assertEqual(Path(self.cfg['progress_path']).read_bytes(),old);self.assertEqual(self.run.report['progress_error_count'],2);self.assertNotIn(SECRET,json.dumps(self.run.report['progress_errors']))
        self.run.report.update(status='PASS',browser_worker_final='A');self.p.finish()
        self.rejects(lambda:m.recover_progress({},self.cfg,self.run.report))
    def test_06_truncated_temporary_preserves_old_snapshot(self):
        path=Path(self.cfg['progress_path']);old=path.read_bytes();original=m.os.fdopen
        class Short:
            def __init__(self,s):self.s=s
            def __enter__(self):self.s.__enter__();return self
            def __exit__(self,*args):return self.s.__exit__(*args)
            def write(self,data):self.s.write(data[:-1]);return len(data)
            def flush(self):return self.s.flush()
            def fileno(self):return self.s.fileno()
        with patch.object(m.os,'fdopen',side_effect=lambda *a,**k:Short(original(*a,**k))):self.p.save()
        self.assertEqual(path.read_bytes(),old);self.assertEqual(self.run.report['progress_error_count'],1);self.assertEqual(list(self.d.glob('.partial-*')),[])
    def test_07_owned_fake_worker_TERM_recovers_unknown(self):
        # The child is this test's direct Popen handle. No PID from logs is used.
        child_code='''import json,sys,time
from pathlib import Path
from check_partial import fixture,request
r,c,p=fixture(Path(sys.argv[1]));ctx=p.action('POST');ctx.__enter__();p.request(request());Path(sys.argv[1]+'/ready').write_text('ready');sys.stdin.readline()
'''
        env=dict(os.environ,PYTHONPATH=str(OUT)+':src:.')
        proc=subprocess.Popen([sys.executable,'-c',child_code,str(self.d)],cwd=ROOT,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            end=time.monotonic()+10
            while not (self.d/'ready').exists():
                self.assertIsNone(proc.poll());self.assertLess(time.monotonic(),end);time.sleep(.01)
            proc.terminate();proc.communicate(timeout=3);self.assertEqual(proc.returncode,-15)
            root={'status':'FAIL','error_type':'TimeoutError','error':'preserved timeout','owned_cleanup':{'exit':0}}
            m.recover_progress(root,self.cfg);v=root['partial_progress']['A'];self.assertEqual(v['outcome'],'UNKNOWN');self.assertFalse(v['worker_final']);self.assertEqual(len(v['requests']),1);self.assertIsNone(v['requests'][0]['response_status']);self.assertEqual(v['in_flight_actions'],[1]);self.assertEqual(root['error'],'preserved timeout')
        finally:
            if proc.poll() is None:proc.terminate();proc.communicate(timeout=3)
    def test_08_whitelist_redaction_and_limits(self):
        with self.p.action('CLICK','#'+SECRET):self.p.request(request())
        req=request('GET');req.url='https://private:'+SECRET+'@invalid.example/api/'+SECRET+'?authorization='+SECRET;self.p.request(req)
        self.run.report['stage']=SECRET;self.p.save();raw=Path(self.cfg['progress_path']).read_bytes()
        self.assertNotIn(SECRET.encode(),raw);self.assertNotIn(b'authorization',raw);self.assertNotIn(b'post_data',raw);self.assertNotIn(b'headers',raw)
        self.assertEqual(self.read()['stage'],'UNKNOWN');self.assertEqual(self.read()['requests'][-1]['route'],'/api/:redacted')
        old=raw
        with self.assertRaises(ValueError):m.progress_atomic(Path(self.cfg['progress_path']),{'huge':'x'*m.PROGRESS_LIMIT})
        self.assertEqual(Path(self.cfg['progress_path']).read_bytes(),old)
        self.p.value['requests']*=201;self.p.save();self.assertEqual(Path(self.cfg['progress_path']).read_bytes(),old);self.assertTrue(self.run.report['progress_errors'])
    def test_09_wrong_identity_sequence_rollback_and_same_sequence_change(self):
        root={};previous=m.recover_progress(root,self.cfg);original=self.read()
        for key,other in [('source_sha','b'*40),('run_number','33'),('phase','B'),('invocation','b'*32)]:
            v=copy.deepcopy(original);v[key]=other;m.progress_atomic(Path(self.cfg['progress_path']),v);self.rejects(lambda:m.recover_progress({},self.cfg))
        m.progress_atomic(Path(self.cfg['progress_path']),original);self.p.save();new=m.recover_progress({},self.cfg,previous=previous)
        m.progress_atomic(Path(self.cfg['progress_path']),original);self.rejects(lambda:m.recover_progress({},self.cfg,previous=new))
        v=copy.deepcopy(original);v['stage']='PHASE_A_CHROME_LAUNCH';m.progress_atomic(Path(self.cfg['progress_path']),v);self.rejects(lambda:m.recover_progress({},self.cfg,previous=previous))
    def test_10_final_partial_conflicts_and_malformed_rejected(self):
        root={};m.recover_progress(root,self.cfg);old=copy.deepcopy(root)
        final=dict(self.run.report,status='PASS',browser_worker_final='A')
        self.rejects(lambda:m.recover_progress(root,self.cfg,final));self.assertEqual(root,old)
        self.run.report.update(status='PASS',browser_worker_final='A');self.p.finish()
        final=copy.deepcopy(self.run.report);final['status']='FAIL';self.rejects(lambda:m.recover_progress({},self.cfg,final))
        final=copy.deepcopy(self.run.report);final['progress_reference']['sequence']+=1;self.rejects(lambda:m.recover_progress({},self.cfg,final))
        self.rejects(lambda:m.recover_progress(root,self.cfg,final));self.assertEqual(root,old)
        v=self.read();v['authorization']=SECRET;m.progress_atomic(Path(self.cfg['progress_path']),v);root={};self.rejects(lambda:m.recover_progress(root,self.cfg));self.assertNotIn('partial_progress',root)
        Path(self.cfg['progress_path']).write_text('{"truncated":');self.rejects(lambda:m.recover_progress({},self.cfg))
    def test_11_role_list_wait_and_original_business_assertions_returned(self):
        # Exercise the real decorators; fake original methods are not Chrome.
        walk=object.__new__(m.Walk);walk.run=self.run;walk.w=SimpleNamespace(wait_for_function=lambda *a,**k:'ready')
        with patch.object(m.guide.Walk,'role',return_value=None),patch.object(m.guide.Walk,'ready',return_value=None):
            walk.role('specialist');walk.ready();walk.wait('()=>true',timeout=30000)
        rows=self.read()['actions'];self.assertEqual([x['kind'] for x in rows],['ROLE','WAIT_READY','WAIT_VIEW']);self.assertEqual(rows[0]['target_actor'],'specialist');self.assertTrue(all(x['state']=='RETURNED' for x in rows));self.assertEqual(self.run.diagnostic_actor,'specialist')
    def test_12_original_gates_waits_and_only_driver_changed(self):
        old=ast.parse(subprocess.check_output(['git','show',SOURCE+':scripts/full_guide_installed_browser_once.py'],cwd=ROOT,text=True));new=ast.parse((ROOT/'scripts/full_guide_installed_browser_once.py').read_text())
        def classes(t):return {n.name:n for n in t.body if isinstance(n,ast.ClassDef)}
        for name in ('Budget','Walk'):
            before={n.name:n for n in classes(old)[name].body if isinstance(n,ast.FunctionDef)};after={n.name:n for n in classes(new)[name].body if isinstance(n,ast.FunctionDef)}
            for key,fn in before.items():
                self.assertEqual([ast.dump(n) for n in ast.walk(fn) if isinstance(n,ast.Assert)],[ast.dump(n) for n in ast.walk(after[key]) if isinstance(n,ast.Assert)],key)
                def waits(f):return sorted(ast.dump(ast.Tuple(elts=n.args+list(n.keywords),ctx=ast.Load())) for n in ast.walk(f) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('wait_for_function','wait'))
                self.assertEqual(waits(fn),waits(after[key]),key)
        self.assertEqual(subprocess.check_output(['git','diff','--name-only','--','src','tests','scripts/guide_installed_browser_once.py','scripts/visual_owned_launch.py','.github/workflows/fictional-park-browser-once.yml','scripts/fictional_park_font_once.py'],cwd=ROOT),b'')
        self.assertEqual(m.RUN,'32');self.assertEqual(len(m.PUBLIC),10)
    def main_failure(self,broken_final):
        # Run the real root finally path with no installed app or subprocess.
        # Only the separate owned fake-worker test above creates a process.
        pending=[]
        @contextmanager
        def server(run):
            run.state=self.d/'state';run.state.mkdir();run.python=Path(sys.executable)
            run.report['origin']='http://127.0.0.1:1234'
            try:yield
            finally:run.report['owned_cleanup']={'cleanup_errors':[],'children':[{'role':'api','exit_code':0},{'role':'postgres','exit_code':0}]}
        @contextmanager
        def owner(run):
            yield SimpleNamespace(execute=lambda *_:SimpleNamespace(fetchone=lambda:{'n':0}))
        def install(run,*_):run.harness=self.d/'harness';run.harness.mkdir()
        def child(argv,**kw):
            cfg=json.loads(Path(argv[-1]).read_text());run=SimpleNamespace(report=cfg['report'],started=cfg['started']);p=m.Progress(run,cfg,time.monotonic())
            ctx=p.action('POST');ctx.__enter__();pending.append(ctx);p.request(request())
            owned=Path(cfg['private'])/'browser-supervision-A';owned.mkdir();(owned/'owned.json').write_text(json.dumps({'operation_status':'FAIL','bound_processes_exited':True}))
            if broken_final:
                Path(cfg['browser_result']).write_text('{"truncated":');return SimpleNamespace(returncode=-15)
            raise subprocess.TimeoutExpired('offline-owned-supervisor',100)
        with patch.dict(os.environ,{'RUNNER_TEMP':str(self.d)}),patch.object(m.base,'require_hosted',return_value=SOURCE),patch.object(m.installed,'current_wheel',return_value=None),patch.object(m.installed,'installation',side_effect=install),patch.object(m.guide,'installed_font_environment',side_effect=lambda env,*_:env),patch.object(m.installed,'server',server),patch.object(m.source,'owner',owner),patch.object(m.installed,'require_work',return_value=None),patch.object(m.subprocess,'run',side_effect=child),patch.object(m.installed,'collect_installation',return_value=None),patch.object(m.installed,'publish_logs',return_value=None),patch.object(m.base,'finish_report',side_effect=lambda report,*a,**kw:report):
            root=m.main()
        self.assertEqual(root['status'],'FAIL');self.assertEqual(root['error_type'],'JSONDecodeError' if broken_final else 'TimeoutExpired');self.assertEqual(root['owned_cleanup']['cleanup_errors'],[]);self.assertTrue(root['owned_browsers']['A']['bound_processes_exited']);self.assertEqual(root['partial_progress']['A']['outcome'],'UNKNOWN');self.assertEqual(root['partial_progress']['A']['in_flight_actions'],[1]);self.assertNotIn('B',root['partial_progress'])
    def test_13_actual_root_finally_after_supervisor_exception(self):self.main_failure(False)
    def test_14_actual_root_finally_after_corrupt_final_report(self):self.main_failure(True)
    def test_15_continue_exception_is_unknown_not_rejected(self):
        req=request();req.url=req.url.split('?')[0];budget=m.Budget(self.run);budget.authorize(('/api/preparations/00000000-0000-4000-8000-000000000001/commands','REVIEW','enterprise'))
        route=SimpleNamespace(request=req,continue_=lambda:(_ for _ in ()).throw(OSError(SECRET)),abort=lambda:None)
        with self.assertRaises(OSError):budget.route(route)
        row=self.read()['requests'][0];self.assertEqual(row['state'],'CONTINUE_ERROR');self.assertEqual(row['business_outcome'],'UNKNOWN');self.assertEqual(row['error_type'],'OSError');self.assertNotIn(SECRET,Path(self.cfg['progress_path']).read_text())

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
    summary=dict(status='OFFLINE_FAULT_INJECTION_PASS_NOT_BROWSER' if result.wasSuccessful() else 'FAIL',test_cases=result.testsRun,failures=len(result.failures),errors=len(result.errors),HTTP=0,PostgreSQL=0,browser=0,CI=0,owned_fake_workers=1,source_parent=SOURCE,driver_sha256=sha256((ROOT/'scripts/full_guide_installed_browser_once.py').read_bytes()).hexdigest())
    (OUT/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));sys.exit(not result.wasSuccessful())
