from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,subprocess,socket,urllib.request,tempfile
from scripts.windows_portable import payload,entry
p=Path('/workspace/scratch/parkweave-windows-portable-20261023');f=p/'ParkWeave-WINDOWS-PAYLOAD-CANDIDATE-00d62b12.zip'
with ZipFile(f) as z:
 manifest=json.loads(z.read(payload.MANIFEST));audit=json.loads(z.read('static-dll-audit.json'))
 (p/'current-candidate-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (p/'current-static-dll-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
 assert manifest['source_commit']=='00d62b1273f99c7fb7d879c939907ba6e63d74eb'
 assert manifest['usable_product'] is False
 modules=[n for n in z.namelist() if n.startswith('runtime/postgresql/lib/') and n.endswith('.dll')]
 assert len(modules)==26
 with tempfile.TemporaryDirectory(prefix='unpacked-frozen-',dir=p) as t:
  root=Path(t);z.extractall(root)
  assert payload.verify_directory(root)==manifest
  def forbidden(*a,**k):raise AssertionError('NO_RUNTIME_OR_NETWORK_IN_OFFLINE_CHECK')
  subprocess.Popen=forbidden;socket.socket.connect=forbidden;socket.create_connection=forbidden;urllib.request.urlopen=forbidden
  gate=entry.readiness(root)
  assert gate['status']=='BLOCKED' and gate['reason']=='OWNER_MUTATION_PAUSED'
  assert not (root/'app/.runtime').exists() and payload.verify_directory(root)==manifest
 result=dict(status='FROZEN_REAL_ASSETS_STATIC_ONLY',source_commit=manifest['source_commit'],candidate=dict(bytes=f.stat().st_size,sha256=sha256(f.read_bytes()).hexdigest(),members=len(z.namelist())),payload_files=len(manifest['files']),default_pg_dynamic_modules=modules,native_files=audit['native_files'],unresolved_dependencies=audit['unresolved'],unverified_api_contracts=audit['unverified_api_contracts'],original_readiness=gate,integrity_before_after_equal=True,Windows='NOT_RUN',PG='NOT_RUN',native_loading='NOT_RUN',installation='NOT_RUN',CI='NOT_RUN',usable_product=False)
 (p/'current-candidate-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ('default_pg_dynamic_modules','unresolved_dependencies','unverified_api_contracts')},ensure_ascii=False))
 print(json.dumps({'unresolved_count':len(audit['unresolved']),'unresolved_names':sorted(set(a['dependency'] for a in audit['unresolved']))}))
