from pathlib import Path
import urllib.request,json,hashlib,time
p=Path(__file__).parent/'assets';url='https://sbp.enterprisedb.com/getfile.jsp?fileid=1260616'
with urllib.request.urlopen(url,timeout=20) as r:
 meta=dict(requested=url,final_url=r.url,content_type=r.headers.get('Content-Type'),content_length=r.headers.get('Content-Length'));print(json.dumps(meta),flush=True)
 (p/'postgres-download-response.json').write_text(json.dumps(meta,indent=2))
 if 'html' in (meta['content_type'] or ''):
  (p/'postgres-download-page.html').write_bytes(r.read(2*1024*1024));raise SystemExit('HTML_REQUIRES_REVIEW_NO_LICENSE_ACCEPTANCE')
 count=0;h=hashlib.sha256();start=time.monotonic()
 with (p/'postgresql-17.11-windows-x64.zip').open('xb') as f:
  while block:=r.read(1024*1024):
   count+=len(block);assert count<=512*1024*1024 and time.monotonic()-start<90
   f.write(block);h.update(block)
 meta.update(bytes=count,sha256=h.hexdigest());(p/'postgres-download-response.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta),flush=True)
