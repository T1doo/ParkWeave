from pathlib import Path
import urllib.request,json,hashlib,subprocess,os
p=Path(__file__).parent;assets=p/'assets';assets.mkdir(exist_ok=True)
urls={'python-3.12.10-embed-amd64.zip':'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip','edb-page.html':'https://www.enterprisedb.com/download-postgresql-binaries'}
for n,url in urls.items():
 with urllib.request.urlopen(url,timeout=20) as r:
  data=r.read(20*1024*1024+1);assert len(data)<=20*1024*1024
 (assets/n).write_bytes(data);print(json.dumps(dict(file=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())),flush=True)
lines=Path('/workspace/ParkWeave/requirements-linux-evidence.txt').read_text().splitlines()
exclude=('fasteners==','pgserver==','platformdirs==','iniconfig==','opentelemetry-api==','packaging==','pluggy==','pygments==','pytest==')
lines=[s for s in lines if s and not s.startswith(exclude)]+['colorama==0.4.6']
(p/'runtime-requirements.txt').write_text('\n'.join(lines)+'\n')
cmd=['/workspace/parkweave-venv/bin/python','-m','pip','download','--index-url','https://pypi.org/simple','--only-binary=:all:','--platform','win_amd64','--python-version','3.12','--implementation','cp','--abi','cp312','--no-deps','--no-cache-dir','--retries','0','--timeout','15','--dest',str(assets/'wheels'),'-r',str(p/'runtime-requirements.txt')]
env=dict(os.environ,PIP_CONFIG_FILE='/dev/null',PIP_DISABLE_PIP_VERSION_CHECK='1');env.pop('PIP_EXTRA_INDEX_URL',None)
with (p/'download-original.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
print(json.dumps(dict(wheel_download_exit=r.returncode,requirements=lines)),flush=True)
