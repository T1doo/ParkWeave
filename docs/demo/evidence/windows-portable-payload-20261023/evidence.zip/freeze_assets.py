from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from email.parser import BytesParser
from concurrent.futures import ThreadPoolExecutor
import urllib.request,json,re
from packaging.requirements import Requirement
from packaging.version import Version
from packaging.markers import default_environment
p=Path(__file__).parent;assets=p/'assets';records=[];metadata={}
python=assets/'python-3.12.10-embed-amd64.zip'
def record(f,kind,version,url,licenses):
 raw=f.read_bytes()
 with ZipFile(f) as z:ls={n:sha256(z.read(n)).hexdigest() for n in licenses}
 return dict(file=f.relative_to(assets).as_posix(),kind=kind,version=version,url=url,bytes=len(raw),sha256=sha256(raw).hexdigest(),license_files=ls)
records.append(record(python,'python','3.12.10','https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip',['LICENSE.txt']))
pg=assets/'postgresql-17.11-windows-x64.zip';pgmeta=json.loads((assets/'postgres-download-response.json').read_text())
records.append(record(pg,'postgresql','17.11-5',pgmeta['final_url'],['pgsql/server_license.txt','pgsql/commandlinetools_3rd_party_licenses.txt']))
wheel_rows=[]
for f in sorted((assets/'wheels').glob('*.whl')):
 with ZipFile(f) as z:
  names=z.namelist();m=BytesParser().parsebytes(z.read(next(n for n in names if n.endswith('.dist-info/METADATA'))))
  licenses=[n for n in names if '.dist-info/' in n and any(w in n.lower().split('/')[-1] for w in ('license','copying','copyright','notice'))]
  assert licenses,(f.name,'no licence text')
  metadata[re.sub('[-_.]+','-',m['Name']).lower()]=m
 wheel_rows.append((f,m,licenses))
def freeze(row):
 f,m,licenses=row;url='https://pypi.org/pypi/'+m['Name']+'/'+m['Version']+'/json'
 cached=p/(m['Name']+'-pypi.json')
 if cached.exists():raw=cached.read_bytes()
 else:
  with urllib.request.urlopen(url,timeout=15) as r:raw=r.read(3*1024*1024+1);assert len(raw)<=3*1024*1024
  cached.write_bytes(raw)
 doc=json.loads(raw)
 a=next(a for a in doc['urls'] if a['filename']==f.name)
 assert sha256(f.read_bytes()).hexdigest()==a['digests']['sha256'] and f.stat().st_size==a['size']
 assert a['url'].startswith('https://files.pythonhosted.org/')
 return record(f,'wheel',m['Version'],a['url'],licenses)
with ThreadPoolExecutor(max_workers=4) as pool:records.extend(pool.map(freeze,wheel_rows))
env=default_environment();env.update(os_name='nt',sys_platform='win32',platform_system='Windows',platform_machine='AMD64',python_version='3.12',python_full_version='3.12.10',implementation_name='cpython',platform_python_implementation='CPython')
edges=[]
for name,m in metadata.items():
 for text in m.get_all('Requires-Dist',[]):
  req=Requirement(text);extras=['','binary'] if name=='psycopg' else ['']
  if req.marker and not any(req.marker.evaluate(dict(env,extra=x)) for x in extras):continue
  dep=re.sub('[-_.]+','-',req.name).lower();assert dep in metadata,(name,dep)
  assert Version(metadata[dep]['Version']) in req.specifier,(name,text,metadata[dep]['Version'])
  edges.append(dict(package=name,requirement=str(req),resolved=metadata[dep]['Version']))
lock=dict(schema='parkweave-windows-runtime-assets/1',scope='STATIC_INSPECTION_CANDIDATE_NOT_END_USER_RELEASE',assets=records,dependency_closure=edges,development_tools_included=False,python_security_status='3.12.10_LAST_OFFICIAL_WINDOWS_EMBED_SUPERSEDED_BY_3.12.15_NOT_RELEASE_ELIGIBLE',redistribution_status='LICENSE_TEXTS_IDENTIFIED_AND_PRESERVED_NOT_A_LEGAL_OR_SECURITY_SIGNOFF')
root=Path('/workspace/ParkWeave/scripts/windows_portable');(root/'runtime-assets.json').write_text(json.dumps(lock,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(assets=len(records),dependency_edges=len(edges),wheel_count=len(wheel_rows),lock_sha256=sha256((root/'runtime-assets.json').read_bytes()).hexdigest())))
