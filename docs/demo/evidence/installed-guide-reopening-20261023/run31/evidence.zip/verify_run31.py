"""Offline evidence consistency only; no browser, HTTP, DB or product actions."""
from pathlib import Path
from hashlib import sha1,sha256
from zipfile import ZipFile
from io import BytesIO
from collections import Counter
import json,struct
p=Path(__file__).parent
read=lambda n:json.loads((p/n).read_text())
digest=lambda b:sha256(b).hexdigest()
canonical=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
sums=dict(line.split('  ',1)[::-1] for line in (p/'checksums.sha256').read_text().splitlines())
assert set(sums)=={f.name for f in p.iterdir() if f.is_file() and f.name!='checksums.sha256'}
assert all(digest((p/name).read_bytes())==h for name,h in sums.items())
source='90de3f8e9a031b470a1e439109b454b203a1d152'
run=read('run-api.json');job=read('job-api.json')['jobs'][0];a=read('artifact-metadata.json')['artifacts'][0]
assert run['id']==39894632342 and run['run_number']==31 and run['run_attempt']==1 and run['head_sha']==source and run['conclusion']=='success'
assert job['id']==120222094587 and job['conclusion']=='success' and all(s['conclusion']=='success' for s in job['steps'])
b=(p/'artifact.zip').read_bytes();assert len(b)==1769183 and a['id']==12475633736
assert a['digest']=='sha256:'+digest(b)=='sha256:882b180934fe141a89ba69625d5b8a5bb5c391e31d8c94c577d7f9d1147c4ff7'
with ZipFile(BytesIO(b)) as z:
    assert len(z.infolist())==9 and sum(i.file_size for i in z.infolist())==2275736<8388608 and all('/' not in n for n in z.namelist())
    r=json.loads(z.read('result.json'))
    for row in read('visual-review.json')['screenshots']:
        b=z.read(row['name']);assert digest(b)==row['sha256'] and list(struct.unpack('>II',b[16:24]))==[row['width'],row['height']]
    texts=[z.read(n) for n in ('current-unfinished-case.txt','reopened-unfinished-case.txt')]
    assert texts[0]==texts[1] and len(texts[0])==14509 and digest(texts[0])=='f8c880521fec5138fbb6ec20da8b1e2bcae3f6a595aafbd864915a770603b28d'
    prefix,raw=texts[0].decode().split('核对数据（UTF-8 JSON，原文按JSON转义；不包含读取凭据）：\n')
    pack=json.loads(raw);assert '核对数据 SHA256：'+digest(canonical(pack))+'\n' in prefix
    wheel=z.read('parkweave-0.1.0-py3-none-any.whl')
    assert len(wheel)==1010975 and digest(wheel)=='1e5fec01565591e5746dc470baeeb5101954d6bd21206443dddc244ebfa2dd1e'
    with ZipFile(BytesIO(wheel)) as w:
        actual={n for n in w.namelist() if n.startswith('parkweave/') and not n.endswith('/')}
        expected=r['installation']['package_files'];assert actual==set(expected) and len(actual)==191
        assert all(digest(w.read(n))==h for n,h in expected.items())
assert r['status']=='PASS' and r['stage']=='COMPLETE' and r['source_sha']==source
assert not any(r[k] for k in ('page_errors','violations','real_model_calls','formal_source','formal_AT35','Windows','PG_restart'))
assert not r.get('error_type') and not r.get('context_cleanup_errors') and not r.get('browser_cleanup_error')
budget=r['request_budget'];assert (budget['POST'],budget['DOM_POST'],budget['API_PREPARATION_POST'],budget['main_GET'],budget['readiness_attempts'],budget['GET'])==(9,9,0,106,19,125)
assert Counter((x['method'],x['status']) for x in r['responses'])=={('GET',200):99,('GET',403):7,('POST',200):5,('POST',201):3,('POST',202):1}
assert all(x['path'].endswith('/fact-clarifications') for x in r['responses'] if x['status']==403)
fresh=[x for x in r['responses'] if x['stage']=='FRESH_CONTEXT_ORIGINAL_IDENTITY_READS'];assert len(fresh)==20 and all(x['method']=='GET' for x in fresh)
assert Counter(x['status'] for x in fresh)=={200:19,403:1}
writes=r['DOM_write_requests'];assert len(writes)==9 and len({x['key'] for x in writes})==9
assert [x['action'] for x in writes]==[None,None,None,'ADD_EVIDENCE','ADD_EVIDENCE','REVIEW','CONFIRM',None,None]
assert [x['actor'] for x in writes]==['enterprise']*5+['specialist']+['enterprise']*3
assert {x['key'] for x in writes}=={x['key'] for x in r['responses'] if x['method']=='POST'}
assert not any(r['empty_business_tables'].values()) and r['installed_worker_exits']==[0]
for x in r['exports']:
    value=x['goal_results'];assert x['pack']==pack and x['sha256']==digest(texts[0]) and x['business_POSTs']==0
    assert value['state']=='UNVERIFIED' and not value['case_goal_completed'] and not value['automatically_verified']
    assert [g['state'] for g in value['results']]==['AWAITING_OWNER_VERIFICATION']+['WAITING_DEPENDENCY']*4
    assert [s['state'] for s in x['plan']['steps']]==['PENDING']+['BLOCKED']*4
    assert not any(e['action']=='VERIFY' for e in x['plan']['events'])
    trace=value['source_trace'];assert trace['trace_sha256']==digest(canonical({k:v for k,v in trace.items() if k!='trace_sha256'}))
assert r['exports'][0]['plan']==r['exports'][1]['plan'] and r['exports'][0]['goal_results']==r['exports'][1]['goal_results']
rec=r['reopening'];assert rec['business_POSTs']==0 and not rec['PG_restart'] and not rec['setup_repeated']
assert rec['named_projection_before']==rec['named_projection_after']
assert len(r['context_closes'])==2 and all(x[k] for x in r['context_closes'] for k in ('guide','popup','context'))
owned=r['owned_browser'];assert owned['status']=='CLEANUP_CONFIRMED' and owned['operation_status']=='PASS' and owned['worker_returncode']==0
assert len(owned['processes'])==7 and all(x['exited'] for x in owned['processes'])
assert not any(owned[k] for k in ('errors','signals','remaining_children','remaining_private_session_members'))
assert r['browser_close']=='CLOSED' and r['server_wrapper_exit']==0 and r['owned_API_listener_refused_after_stop']
assert r['owned_cleanup']['postgres_marker_absent'] and not r['owned_cleanup']['cleanup_errors'] and all(x['exit_code']==0 for x in r['owned_cleanup']['children'])
assert r['work_completion_seconds']<=270 and r['browser_operation_seconds']<=85 and r['seconds']<=360
assert len(r['font_observations'])==2 and all(x['complete'] for x in r['font_observations'])
assert len(r['installed_CJK_font']['required_codepoints'])==685 and '--no-sandbox' not in r['chrome_arguments']
assert set(r['process_installation_attestations'])=={'setup-attestation','api-attestation','worker-0-attestation'}
assert all(len(v)==2 and all(x['wheel_sha256']==digest(wheel) and x['isolated'] and not x['PYTHONPATH'] for x in v) for v in r['process_installation_attestations'].values())
log=(p/'ci-original.log').read_text();assert len(log)==619663 and len(log.encode())==644609
assert digest(log.encode())=='3956955a761913fb0d27405792cc370322b2dc316c6db75d3675428db1f76bbd'
rows=[s.partition('Z ')[2] for s in log.splitlines() if s.partition('Z ')[2].startswith('{"scope": "INSTALLED_GUIDE_NEW_DOM_INPUT_UNFINISHED_TXT_FRESH_REOPEN"')]
assert len(rows)==1;v=json.loads(rows[0]);assert v['status']=='PENDING_FINALIZATION'
v['status']=v.pop('observation_outcome');v.pop('terminal_result');assert v=={k:v for k,v in r.items() if k not in ('seconds','seconds_scope')}
assert 'FINALIZATION_OUTPUT_CHECKPOINT' in log and 'upload aborted' not in log.lower()
assert read('actual-review.json')['status']=='LIMITED_ACK'
print(json.dumps(dict(status='RUN31_ARCHIVE_CONSISTENT_NOT_NEW_EXECUTION',source=source,run=31,DOM_POST=9,API_preparation_POST=0,reopening_GET=20,reopening_POST=0,TXT_bytes=14509)))
