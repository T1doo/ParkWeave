"""Targeted offline boundary/cleanup checks; no HTTP, PG or browser."""
import ast, importlib, json, subprocess
from pathlib import Path
from types import SimpleNamespace
root=Path('/workspace/ParkWeave')
m=importlib.import_module('scripts.guide_installed_browser_once')
results=[]
class Request:
    method='POST';url='http://127.0.0.1:1234/api/preparations'
    headers={'authorization':'Bearer '+('a'*43),'idempotency-key':'00000000-0000-4000-8000-000000000001'}
    post_data_json={}
class Route:
    request=Request()
    def continue_(self):self.continued=True
    def abort(self):self.aborted=True
def budget():
    r=SimpleNamespace(report={'origin':'http://127.0.0.1:1234','violations':[]},tokens={'enterprise':'a'*43},ready=2)
    return m.Budget(r)
b=budget();b.authorize(('/api/preparations',None,'enterprise'));x=Route();b.route(x)
assert x.continued and b.posts==1 and not b.queue and b.run.report['request_budget']['API_PREPARATION_POST']==0
results.append('authorized_original_keyed_DOM_write_counted_once')
for kind in ('readonly','wrong_actor','VERIFY','tenth_POST'):
    b=budget();b.authorize(('/api/preparations',None,'enterprise'));r=Route();r.request=Request()
    if kind=='readonly':b.readonly=True
    if kind=='wrong_actor':r.request.headers={**Request.headers,'authorization':'Bearer '+('b'*43)}
    if kind=='VERIFY':r.request.post_data_json={'action':'VERIFY'}
    if kind=='tenth_POST':b.posts=9
    try:b.route(r)
    except AssertionError:pass
    else:raise AssertionError(kind)
    assert r.aborted and b.run.report['violations'];results.append(kind+'_rejected')
# Every cleanup is attempted even when screenshot, guide, token and context fail.
called=[]
class Page:
    def __init__(self,name):self.name=name;self.closed=False
    def is_closed(self):return self.closed
    def screenshot(self,**kw):called.append('screenshot');raise OSError('controlled screenshot failure')
    def locator(self,selector):return self
    def input_value(self):called.append('token');raise OSError('controlled token read failure')
    def close(self):
        called.append(self.name)
        if self.name=='guide':raise OSError('controlled guide failure')
        self.closed=True
class Context:
    def close(self):called.append('context');raise OSError('controlled context failure')
w=object.__new__(m.Walk);w.guide=Page('guide');w.w=Page('popup');w.context=Context()
w.run=SimpleNamespace(report={'stage':'CONTROLLED_CLEANUP'},public=Path('/tmp'))
primary=ValueError('controlled business failure');m.failed(w.run.report,primary)
try:w.close(primary)
except BaseExceptionGroup as e:assert e.exceptions[0] is primary and len(e.exceptions)==4
else:raise AssertionError('close must fail')
assert called==['screenshot','guide','token','popup','context'] and w.w.closed
assert w.run.report['error']=='controlled business failure' and w.run.report['failure_screenshot_error']=='OSError'
m.failed(w.run.report,RuntimeError('controlled later supervisor failure'))
assert w.run.report['status']=='FAIL' and w.run.report['error']=='controlled business failure' and w.run.report['later_errors'][-1]['error']=='controlled later supervisor failure'
results.append('primary_and_all_cleanup_attempts_preserved_no_success')
# Execute the actual worker exception paths with a fake SDK only. No executable
# browser or network is started, and none of the business helpers are invoked.
from unittest.mock import patch
import tempfile,time
private=Path(tempfile.mkdtemp(prefix='guide-driver-fault-',dir=Path(__file__).parent))
(private/'sessions.json').write_text(json.dumps({'enterprise':'a'*43,'specialist':'b'*43,'executor':'c'*43}))
def config():return dict(started=time.monotonic(),report={'responses':[],'page_errors':[],'violations':[],'stage':'START'},private=str(private),public=str(private),harness=str(private),state=str(private),python='/not-executed',ready=0,chrome_env={},browser_result=str(private/'worker-result.json'))
class LaunchFail:
    def launch(self,**kw):raise ValueError('controlled original launch failure')
class SDK:
    def __init__(self,chromium):self.chromium=chromium
    def __enter__(self):return self
    def __exit__(self,*args):raise OSError('controlled SDK teardown failure')
with patch('playwright.sync_api.sync_playwright',lambda:SDK(LaunchFail())):
    try:m.browser_worker(config(),time.monotonic())
    except OSError:pass
    else:raise AssertionError('SDK teardown failure must propagate')
saved=json.loads((private/'worker-result.json').read_text())
assert saved['status']=='FAIL' and saved['error']=='controlled original launch failure'
assert any(x['error']=='controlled SDK teardown failure' for x in saved['later_errors'])
results.append('actual_worker_launch_primary_survives_SDK_teardown')
class Browser:
    version='FAKE_NOT_A_BROWSER'
    def close(self):called.append('browser');raise OSError('controlled browser close failure')
class Launcher:
    def launch(self,**kw):return Browser()
class Fresh:
    def __init__(self,*args):pass
    def open(self):raise ValueError('controlled original fresh read failure')
    def close(self,primary):assert str(primary)=='controlled original fresh read failure';raise OSError('controlled fresh context close failure')
with patch('playwright.sync_api.sync_playwright',lambda:SDK(Launcher())),patch.object(m.base.resource,'verify_sandbox',lambda *_:None),patch.object(m,'intake',lambda *_:()),patch.object(m.tail,'snapshot',lambda *_:{}),patch.object(m,'Walk',Fresh):
    try:m.browser_worker(config(),time.monotonic())
    except OSError:pass
    else:raise AssertionError('SDK teardown failure must propagate')
saved=json.loads((private/'worker-result.json').read_text())
assert saved['status']=='FAIL' and saved['error']=='controlled original fresh read failure' and called[-1]=='browser'
assert {'controlled fresh context close failure','controlled browser close failure','controlled SDK teardown failure'}<={x['error'] for x in saved['later_errors']}
results.append('actual_worker_fresh_primary_survives_context_browser_SDK_failures')
tree=ast.parse((root/'scripts/guide_installed_browser_once.py').read_text())
expressions=[]
for node in ast.walk(tree):
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr in ('evaluate','wait_for_function') and node.args and isinstance(node.args[0],ast.Constant) and isinstance(node.args[0].value,str):expressions.append(node.args[0].value)
subprocess.run(['node','-e','for(const s of JSON.parse(process.argv[1]))new Function("return ("+s+")");',json.dumps(expressions)],check=True)
manifest=json.loads((root/'docs/F2/evidence/eng057-job-shards.json').read_text())
from hashlib import sha256
for mapping in ('source_file_sha256','implementation_source_sha256'):
    for name,digest in manifest[mapping].items():assert sha256((root/name).read_bytes()).hexdigest()==digest,name
assert subprocess.check_output(['git','diff','--name-only','--','src','tests'],cwd=root)==b''
assert m.RUN=='31' and len(m.PUBLIC)==10
assert 'github.run_number == 31' in (root/'.github/workflows/fictional-park-browser-once.yml').read_text()
report=dict(status='OFFLINE_DRIVER_BOUNDARY_CHECKS_PASS_NOT_BROWSER',checks=results,JS_expressions_parsed=len(expressions),source_fingerprints=sum(len(manifest[k]) for k in ('source_file_sha256','implementation_source_sha256')),fingerprints_not_tests=True,product_and_tests_unchanged=True,HTTP=0,browser=0,PG=0,CI=0)
print(json.dumps(report))
Path(__file__).with_name('preflight.json').write_text(json.dumps(report,indent=2)+'\n')
