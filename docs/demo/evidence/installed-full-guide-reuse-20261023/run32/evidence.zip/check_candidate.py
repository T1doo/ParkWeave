"""Offline request-ledger, exception and syntax checks; no real service/browser."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import ast,json,subprocess,tempfile,time,hashlib
from scripts import full_guide_installed_browser_once as m
p=Path(__file__).parent;root=m.ROOT;results=[]
def context(phase='A',report=None):return SimpleNamespace(phase=phase,ready=19,tokens={'enterprise':'a'*43,'specialist':'b'*43,'executor':'c'*43},report=report or {'origin':'http://127.0.0.1:1234','violations':[]})
class Route:
    def __init__(self,path,action=None,actor='enterprise',key=None,method='POST'):
        self.request=SimpleNamespace(method=method,url='http://127.0.0.1:1234'+path,post_data_json={} if action is None else {'action':action},headers={'authorization':'Bearer '+{'enterprise':'a','specialist':'b','executor':'c'}[actor]*43})
        if key is not None:self.request.headers['idempotency-key']=key
        self.continued=False;self.aborted=False
    def continue_(self):self.continued=True
    def abort(self):self.aborted=True
run=context();a=m.Budget(run)
for n in range(30):
    preview=n<4;path='/api/resource-delivery/preview' if preview else '/api/commands';action=None if preview else 'VERIFY'
    key=None if preview else f'00000000-0000-4000-8000-{n:012d}'
    a.authorize((path,action,'enterprise'));r=Route(path,action,key=key);a.route(r);assert r.continued
assert a.posts==30 and len(a.keys)==26 and not a.queue
run.phase='B';b=m.Budget(run);assert b.posts==30 and b.keys==a.keys
for n in range(30,39):
    b.authorize(('/api/B',None,'enterprise'));r=Route('/api/B',key=f'00000000-0000-4000-8000-{n:012d}');b.route(r);assert r.continued
assert b.posts==39 and len(b.keys)==35 and run.report['request_budget']['API_PREPARATION_POST']==0
results.append('two_segments_share39_POST_four_previews35_unique_keys')
def rejection(kind):
    run=context();b=m.Budget(run);path='/api/write';key='00000000-0000-4000-8000-000000000099'
    b.authorize((path,'APPROVE','enterprise'));r=Route(path,'APPROVE',key=key)
    if kind=='A31':b.posts=30
    if kind=='B40':b.posts=39;run.phase='B'
    if kind=='readonly':b.readonly=True
    if kind=='wrong_actor':r.request.headers['authorization']='Bearer '+('b'*43)
    if kind=='wrong_action':r.request.post_data_json={'action':'REVOKE'}
    if kind=='unkeyed_write':r.request.headers.pop('idempotency-key')
    if kind=='keyed_preview':b.queue=[('/api/preview',None,'enterprise')];r.request.url='http://127.0.0.1:1234/api/preview'
    if kind=='old_key':b.keys.add(key)
    if kind=='GET361':b.reads=360;r.request.method='GET'
    try:b.route(r)
    except AssertionError:pass
    else:raise AssertionError(kind)
    assert r.aborted and run.report['violations']
for kind in ('A31','B40','readonly','wrong_actor','wrong_action','unkeyed_write','keyed_preview','old_key','GET361'):rejection(kind)
results.append('phase_cumulative_readonly_actor_action_key_GET_bounds_reject')
for now,reserve,ok in ((34,235,True),(36,235,False),(125,145,True),(126,145,False)):
    with patch.object(m.installed.time,'monotonic',lambda:now):
        try:m.installed.require_work(SimpleNamespace(started=0),reserve)
        except AssertionError:assert not ok
        else:assert ok
results.append('admission_uses_shared270s_anchor_with_cleanup_reserve')
private=Path(tempfile.mkdtemp(prefix='full-guide-fault-',dir=p));(private/'sessions.json').write_text(json.dumps({'enterprise':'a'*43,'specialist':'b'*43,'executor':'c'*43}))
def config():return dict(started=time.monotonic(),phase='A',ready=0,report={'stage':'START','responses':[],'violations':[],'page_errors':[]},private=str(private),public=str(private),harness=str(private),state=str(private),python='/not-executed',browser_result=str(private/'result.json'),chrome_env={})
class SDK:
    def __init__(self,launcher):self.chromium=launcher
    def __enter__(self):return self
    def __exit__(self,*_):raise OSError('controlled SDK teardown failure')
class Launcher:
    def launch(self,**kw):raise ValueError('controlled launch primary')
with patch('playwright.sync_api.sync_playwright',lambda:SDK(Launcher())):
    try:m.browser_worker(config(),time.monotonic())
    except OSError:pass
    else:raise AssertionError('teardown must fail')
v=json.loads((private/'result.json').read_text());assert v['status']=='FAIL' and v['error']=='controlled launch primary' and any(x['error']=='controlled SDK teardown failure' for x in v['later_errors'])
results.append('actual_new_worker_launch_primary_survives_SDK_teardown')
class Browser:
    version='FAKE_NOT_A_BROWSER'
    def close(self):raise OSError('controlled browser close failure')
class Launcher2:
    def launch(self,**kw):return Browser()
def phase_failure(*_):raise ValueError('controlled phase business primary')
with patch('playwright.sync_api.sync_playwright',lambda:SDK(Launcher2())),patch.object(m.base.resource,'verify_sandbox',lambda *_:None),patch.object(m,'phase_flow',phase_failure):
    try:m.browser_worker(config(),time.monotonic())
    except OSError:pass
    else:raise AssertionError('teardown must fail')
v=json.loads((private/'result.json').read_text());assert v['status']=='FAIL' and v['error']=='controlled phase business primary'
assert {'controlled browser close failure','controlled SDK teardown failure'}<={x['error'] for x in v['later_errors']}
results.append('actual_new_worker_phase_primary_survives_browser_SDK_cleanup')
cfg=config();cfg['phase']='B';cfg['report']['DOM_write_requests']=run.report['DOM_write_requests'][:30]
cfg['report']['owned_browsers']={'A':{'operation_status':'PASS','preserved_fixture':True}}
with patch('playwright.sync_api.sync_playwright',lambda:SDK(Launcher2())),patch.object(m.base.resource,'verify_sandbox',lambda *_:None),patch.object(m,'phase_flow',phase_failure):
    try:m.browser_worker(cfg,time.monotonic())
    except OSError:pass
    else:raise AssertionError('teardown must fail')
v=json.loads((private/'result.json').read_text());assert v['status']=='FAIL' and v['error']=='controlled phase business primary'
assert len(v['DOM_write_requests'])==30 and v['owned_browsers']['A']['preserved_fixture'] and v['browser_worker_final']=='B'
results.append('second_segment_failure_preserves_first_segment_evidence')
tree=ast.parse((root/'scripts/full_guide_installed_browser_once.py').read_text());expressions=[]
for n in ast.walk(tree):
    if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('evaluate','evaluate_all','wait_for_function') and n.args and isinstance(n.args[0],ast.Constant):expressions.append(n.args[0].value)
subprocess.run(['node','-e','for(const s of JSON.parse(process.argv[1]))new Function("return ("+s+")");',json.dumps(expressions)],check=True)
import re
html=(root/'src/parkweave/web.html').read_text()+(root/'src/parkweave/park_demo_web.html').read_text()
ids=set(re.findall(r'\bid="([\w-]+)"',html));selectors=set()
for n in ast.walk(tree):
    if isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value.startswith('#'):selectors.update(re.findall(r'#([A-Za-z][\w-]*)',n.value))
assert selectors<=ids,selectors-ids
manifest=json.loads((root/'docs/F2/evidence/eng057-job-shards.json').read_text())
for k in ('source_file_sha256','implementation_source_sha256'):
    for name,h in manifest[k].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
assert subprocess.check_output(['git','diff','--name-only','--','src','tests','scripts/guide_installed_browser_once.py','scripts/visual_owned_launch.py'],cwd=root)==b''
assert m.RUN=='32' and len(m.PUBLIC)==10
report=dict(status='OFFLINE_BOUNDARY_FAULT_CHECKS_PASS_NOT_BROWSER',checks=results,JS_expressions_parsed=len(expressions),literal_selector_IDs_exist=len(selectors),source_fingerprints=sum(len(manifest[k]) for k in ('source_file_sha256','implementation_source_sha256')),not_test_counts=True,HTTP=0,PG=0,browser=0,CI=0)
(p/'preflight.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
