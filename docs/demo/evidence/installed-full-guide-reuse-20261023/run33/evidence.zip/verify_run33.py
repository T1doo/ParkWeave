"""Offline check of retained run33 originals; no browser, HTTP, DB or CI."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from zipfile import ZipFile
from tempfile import TemporaryDirectory
import json,io

p=Path(__file__).parent
if (p/'official').exists():p=p/'official'
digest=lambda x:sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert sha256((p/'artifact.zip').read_bytes()).hexdigest()=='b5da44539f99be7c8bfc01024ff845f2946149574cc57e2887a4d5a1bf7a42c2'
assert sha256((p/'ci-original.log').read_bytes()).hexdigest()=='6cde347bee2947dc16b7bfd43e20846ba0b3ac2e8de14cffe885583c7185b10b'
with ZipFile(p/'artifact.zip') as z:
    assert len(z.infolist())==9 and sum(x.file_size for x in z.infolist())<=8*1024*1024
    assert all('/' not in x.filename and '\\' not in x.filename and not x.filename.startswith('.') for x in z.infolist())
    members={n:z.read(n) for n in z.namelist()}
r=json.loads(members['result.json']);assert r['status']=='PASS' and r['source_sha']=='c83e93dc3bafe55a00f5c2531e8a9e9eedf5002c'
assert r['invocation']=='51eed5572b4843ae87f3a63749404b6f' and not r['violations'] and not r['page_errors']
requests=r['DOM_write_requests'];responses=r['responses'];assert len(requests)==39
assert Counter(x['phase'] for x in requests)==Counter(A=30,B=9)
previews=[x for x in requests if x['preview']];keys=[x['key'] for x in requests if not x['preview']]
assert len(previews)==4 and all(x['key'] is None for x in previews) and len(set(keys))==len(keys)==35
assert Counter((x['method'],x['status']) for x in responses)==Counter({('GET',200):296,('GET',403):19,('POST',200):24,('POST',201):13,('POST',202):2})
assert all(x['path'].endswith('/fact-clarifications') for x in responses if x['status']==403)
assert r['request_budget']['POST']==39 and r['request_budget']['API_PREPARATION_POST']==0 and r['request_budget']['GET']==336
assert r['request_budget']['main_GET']==315 and r['request_budget']['readiness_attempts']==21
for request in requests:
    body_sha=sha256(json.dumps(request['body'],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    rows=[x for x in responses if x['method']=='POST' and x['path']==request['path'] and x.get('key')==request['key'] and x['body_sha256']==body_sha]
    assert len(rows)==1 and 200<=rows[0]['status']<300
def original(action):
    req=next(x for x in requests if x['action']==action)
    return next(x['response'] for x in responses if x['method']=='POST' and x.get('key')==req['key'])
assert original('ACKNOWLEDGE')['step']['state']=='LOCAL_ACKNOWLEDGED'
assert original('REVALIDATE')['local_record_state']=='READY' and original('CLOSE_LOCAL_RECORD')['local_record_state']=='LOCAL_RECORD_CLOSED'
assert [x['adapter'] for x in r['explicit_verifications']]==['P1','P2','P3','P4','P5']
for x in r['explicit_verifications']:
    rows=[q for q in requests if q['key']==x['receipt']['request_key']];assert len(rows)==1 and rows[0]['phase']=='A' and rows[0]['action']=='VERIFY' and rows[0]['actor']=='enterprise'
assert not any(x['action']=='VERIFY' for x in requests if x['phase']=='B')
for phase,events in r['independent_material_decisions'].items():
    assert len(events)==2
    for event in events:
        q=next(x for x in requests if x['phase']==phase and x['action']==event['action']);assert q['key']==event['request_key']
        observed=next(x for x in responses if x['method']=='POST' and x.get('key')==q['key'])
        assert observed['response']==event['payload'] and event['actor_id']=='ordinary-demo-'+q['actor']
        assert all(event['payload'][k]==r['records'][phase][k] for k in ('preparation_id','case_id','run_id'))
reuse=r['reuse'];proof=reuse['original_response']['material_reuse'];material=reuse['actual_new_material']
assert proof['source_preparation_id']==r['records']['A']['preparation_id'] and reuse['original_response']['preparation_id']==r['records']['B']['preparation_id']
assert proof['requires_independent_review'] and material['id']==proof['target_evidence_id']!=proof['source_evidence_id']
assert material['version']==1 and sha256(material['text'].encode()).hexdigest()==material['source_sha256']==proof['source_evidence_sha256']==proof['target_sha256']
assert all(r['records']['A'][k]!=r['records']['B'][k] for k in ('preparation_id','case_id','run_id','plan_id','goal'))
assert r['A_after_B']['named_projection_after']==r['A_sealed_snapshot'] and r['A_after_B']['business_POSTs']==0
assert len(r['exports'])==3
for n,export in enumerate(r['exports']):
    if export['file'] is not None:
        text=members[export['file']].decode();assert len(text.encode())==export['bytes'] and sha256(text.encode()).hexdigest()==export['sha256']
        prefix,raw=text.split('核对数据（UTF-8 JSON，原文按JSON转义；不包含读取凭据）：\n');pack=json.loads(raw);assert pack==export['pack'] and '核对数据 SHA256：'+digest(pack)+'\n' in prefix
    g=export['goal_results'];expected=['LOCAL_OUTPUT_VERIFIED']*5 if n!=1 else ['AWAITING_OWNER_VERIFICATION']+['WAITING_DEPENDENCY']*4
    assert [x['state'] for x in g['results']]==expected and not g['case_goal_completed'] and not g['automatically_verified']
    assert (g['qualification'],g['external_acceptance'],g['offline_fulfillment'])==('NOT_EVALUATED','NOT_SUBMITTED','NO_EVIDENCE')
    trace=g['source_trace'];assert trace['trace_sha256']==digest({k:v for k,v in trace.items() if k!='trace_sha256'})
    for row in g['results']:assert row['result_sha256']==digest({k:v for k,v in row.items() if k!='result_sha256'}) and row['adoption_trace_sha256']==trace['trace_sha256']
assert all(r['exports'][0][k]==r['exports'][2][k] for k in ('goal_results','plan','sha256','bytes'))
assert [x['state'] for x in r['exports'][0]['plan']['steps']]==['VERIFIED']*5
assert [x['state'] for x in r['exports'][1]['plan']['steps']]==['PENDING']+['BLOCKED']*4
io_totals={};observed=Counter()
for phase,v in r['partial_progress'].items():
    assert v['outcome']=='PASS' and v['state']=='COMPLETE' and v['worker_final'] and not v['in_flight_actions'] and not v['checkpoint_errors']
    assert v['source_sha']==r['source_sha'] and v['run_number']=='33' and v['phase']==phase and v['invocation']==sha256((r['invocation']+':'+phase).encode()).hexdigest()[:32]
    assert all(x['state']=='RETURNED' for x in v['actions'])
    assert all(x['state']=='CONTINUED' and x['response_status'] is not None and x['body_state']=='OBSERVER_RETURNED' and x['business_outcome']=='UNKNOWN' for x in v['requests'])
    observed.update((x['method'],x['response_status']) for x in v['requests'])
    full=r['progress_io_summaries'][phase];prefix=v['checkpoint_io']
    assert prefix['completed_saves']==v['sequence']-1 and full['completed_saves']==v['sequence'] and prefix['failed_saves']==full['failed_saves']==0
    assert 0<=prefix['successful_fsync_seconds']<=full['successful_fsync_seconds']<=full['total_save_seconds'] and prefix['total_save_seconds']<=full['total_save_seconds']
    io_totals[phase]=full
assert observed==Counter((x['method'],x['status']) for x in responses)
v=r['partial_progress']['B'];assert sha256(json.dumps(v,separators=(',',':'),allow_nan=False).encode()).hexdigest()==r['progress_reference']['sha256']
assert len(r['phase_admissions'])==2 and r['phase_admissions'][1]['elapsed']>r['partial_progress']['A']['root_elapsed']
for phase,o in r['owned_browsers'].items():
    assert o['status']=='CLEANUP_CONFIRMED' and o['operation_status']=='PASS' and o['worker_returncode']==0 and o['bound_processes_exited'] and o['subtree_complete'] and not o['errors'] and not o['signals']
    assert all(x['exited'] for x in o['processes']) and len(o['processes'])==7
assert r['installed_worker_exits']==[0,0] and r['server_wrapper_exit']==0 and r['owned_API_listener_refused_after_stop']
assert not r['owned_cleanup']['cleanup_errors'] and all(x['exit_code']==0 for x in r['owned_cleanup']['children'])
assert all(all(x[k] for k in ('guide','popup','context')) for x in r['context_closes']) and r['browser_closes']=={'A':'CLOSED','B':'CLOSED'}
assert r['work_completion_seconds']<270 and r['seconds']<360 and all(x<85 for x in r['browser_segment_seconds'].values())
with ZipFile(io.BytesIO(members['parkweave-0.1.0-py3-none-any.whl'])) as z:
    assert len(r['installation']['package_files'])==191
    for n,h in r['installation']['package_files'].items():assert sha256(z.read(n)).hexdigest()==h
assert set(r['process_installation_attestations'])=={'setup-attestation','api-attestation','worker-0-attestation','worker-1-attestation'}
assert all(len(v)==2 and all(x['isolated'] and not x['PYTHONPATH'] and x['verified_package_files']==191 for x in v) for v in r['process_installation_attestations'].values())
lines=(p/'ci-original.log').read_text().splitlines();rows=[json.loads(x[x.index('{'):]) for x in lines if '"scope": "INSTALLED_FULL_NO_MODEL_A_AND_INDEPENDENT_REUSE_B"' in x and '"status": "PENDING_FINALIZATION"' in x]
assert len(rows)==1;observation=rows[0];observation['status']=observation.pop('observation_outcome');observation.pop('terminal_result');result={k:v for k,v in r.items() if k not in ('seconds','seconds_scope')};assert observation==result
for n in ('run-api.json','job-api.json'):
    j=json.loads((p/n).read_text());assert j['conclusion']=='success' if n=='run-api.json' else all(x['conclusion']=='success' and all(s['conclusion']=='success' for s in x['steps']) for x in j['jobs'])
summary=dict(status='LIMITED_RUN33_ORIGINALS_VERIFIED_NOT_NEW_EXECUTION',source_sha=r['source_sha'],DOM_POST=39,API_PREPARATION_POST=0,main_GET=315,GET200=296,GET403=19,readiness=21,total_GET=336,missing_HTTP_response=0,unfinished_diagnostic_actions=0,unknown_request_business_fields='All354remainUNKNOWN by design;original business assertions and responses are separate proof',runtime_artifact_members=9,runtime_uncompressed_bytes=sum(len(v) for v in members.values()),package_files=191,io=io_totals,work_completion_seconds=r['work_completion_seconds'],browser_segment_seconds=r['browser_segment_seconds'],Case_complete=False,PG_restart=False,run32_root_cause='UNKNOWN_UNCHANGED',summary_body='NOT_INDEPENDENTLY_FETCHED')
print(json.dumps(summary,ensure_ascii=False))
