"""Exercise extracted source imports/parser only; deny runtime before import."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,subprocess,sys,tempfile,os

p=Path(__file__).parent;repo=Path('/workspace/ParkWeave');build=json.loads((p/'build.json').read_text());bundle=repo/'deliverables/local-synthetic-demo'/build['zip']
assert sha256(bundle.read_bytes()).hexdigest()==build['sha256']
child=r'''
import sys,subprocess,socket,urllib.request,os,json,io,contextlib
from pathlib import Path
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
def denied(*a,**k):raise AssertionError('OFFLINE_RUNTIME_CALL_FORBIDDEN')
subprocess.Popen=denied;subprocess.run=denied;subprocess.check_output=denied;os.system=denied
socket.create_connection=denied;socket.socket.connect=denied;urllib.request.urlopen=denied
import psycopg,pgserver
psycopg.connect=denied;pgserver.get_server=denied
from scripts import ordinary_synthetic_demo as demo,material_only_demo,linux_fixture_server,local_demo_inputs
import parkweave
assert not (root/'.git').exists()
modules=[demo,material_only_demo,linux_fixture_server,local_demo_inputs,parkweave]
paths=[str(Path(m.__file__).resolve().relative_to(root)) for m in modules]
assert paths[-1]=='src/parkweave/__init__.py'
marker=json.loads((root/'BUNDLE.json').read_text());binding=demo.source_binding()
helpers={'scripts/'+n for n in ('ordinary_synthetic_demo.py','material_only_demo.py','linux_fixture_server.py','local_demo_inputs.py')}
expected={n:v['sha256'] for n,v in marker['tracked_source_files'].items() if n.startswith('src/parkweave/') or n in helpers}
assert binding['files']==expected and len(expected)==195
observed=[]
for argv,expected_exit in [(['--help'],0),(['serve'],2),(['setup','--state-dir','/tmp/not-used'],2),(['setup','--local-demo-config','/tmp/not-used/config.json'],2),(['serve','--state-dir','/tmp/not-used','--with-local-catalog'],2),(['serve','--state-dir','/tmp/not-used','--with-local-resource-approval'],2)]:
 sys.argv=['ordinary-demo',*argv];stdout=io.StringIO();stderr=io.StringIO()
 with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
  try:demo.main()
  except SystemExit as e:actual=e.code
  else:raise AssertionError('parser unexpectedly entered runtime')
 assert actual==expected_exit
 observed.append(dict(arguments=argv,exit_code=actual,stdout=stdout.getvalue(),stderr=stderr.getvalue()))
print(json.dumps(dict(status='EXTRACTED_IMPORT_AND_PARSER_ONLY_PASS',source_commit=marker['source_commit'],module_files=paths,content_bound_files=len(expected),git_required=False,commands=observed,PG=False,HTTP=False,browser=False,installation=False)))
'''
with tempfile.TemporaryDirectory(prefix='ordinary-unzip-',dir=p) as t:
 root=Path(t)/'source';root.mkdir()
 with ZipFile(bundle) as z:
  assert len(z.namelist())==211 and len(z.namelist())==len(set(z.namelist()))
  assert all(not n.startswith('/') and '..' not in Path(n).parts and '\\' not in n for n in z.namelist());z.extractall(root)
  original={n:sha256(z.read(n)).hexdigest() for n in z.namelist()}
  for line in z.read('SHA256SUMS').decode().splitlines():
   h,n=line.split('  ',1);assert original[n]==h
 env={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8'}
 result=subprocess.run([sys.executable,'-I','-B','-c',child,str(root)],cwd=root,env=env,capture_output=True,text=True,timeout=15)
 (p/'entry-original.stdout').write_text(result.stdout);(p/'entry-original.stderr').write_text(result.stderr)
 assert result.returncode==0,result.stderr
 report=json.loads(result.stdout);assert report['source_commit']==build['source_commit']
 after={str(f.relative_to(root)):sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file()};assert after==original
 report['extracted_payload_unchanged']=True;report['bundle_sha256']=build['sha256']
 (p/'entry-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k!='commands'},ensure_ascii=False))
