"""Offline source-bundle delivery checks; no app/service/DB/browser execution."""
import importlib.util
from pathlib import Path
import subprocess,sys,tempfile,unittest
SCRIPT=Path("/workspace/ParkWeave/scripts/demo_preflight.py")

class OrdinarySourceBundleTests(unittest.TestCase):
    """Source delivery only: no install, import of the app, or database startup."""
    def bundle(self, folder):
        script = SCRIPT.with_name('package_local_synthetic_demo.py')
        spec = importlib.util.spec_from_file_location('source_bundle', script)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        root = SCRIPT.parents[1]
        commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
        path = Path(folder) / 'ordinary.zip'
        return module, root, commit, path

    def test_ordinary_launcher_dependency_closure_is_in_frozen_source_bundle(self):
        import hashlib
        import json
        from zipfile import ZipFile
        with tempfile.TemporaryDirectory() as folder:
            module, root, commit, path = self.bundle(folder)
            report = module.build(root, commit, path)
            with ZipFile(path) as archive:
                names = archive.namelist()
                expected = ('ordinary_synthetic_demo.py', 'material_only_demo.py',
                            'linux_fixture_server.py', 'local_demo_inputs.py')
                for name in expected:
                    self.assertEqual(archive.read('scripts/' + name), subprocess.check_output(
                        ['git', 'show', commit + ':scripts/' + name], cwd=root))
                self.assertIn('docs/demo/OrdinarySyntheticDemo.md', names)
                self.assertIn('requirements-linux-evidence.txt', names)
                self.assertFalse(any(name.startswith(('.git/', '.runtime/', 'tests/')) for name in names))
                self.assertNotIn('scripts/full_guide_installed_browser_once.py', names)
                metadata = json.loads(archive.read('BUNDLE.json'))
                self.assertIn('ORDINARY_SYNTHETIC', metadata['entry_scopes'])
                self.assertFalse(metadata['ordinary_launcher_requires_git_checkout'])
                self.assertFalse(metadata['business_operations_performed'])
                self.assertEqual(metadata['ordinary_runtime_by_packaging'], 'NOT_RUN')
                for name, info in metadata['tracked_source_files'].items():
                    self.assertEqual(hashlib.sha256(archive.read(name)).hexdigest(), info['sha256'])
                self.assertEqual(metadata['source_commit'], report['source_commit'])

    def test_ordinary_bundle_is_reproducible_and_preserves_existing_output(self):
        with tempfile.TemporaryDirectory() as folder:
            module, root, commit, path = self.bundle(folder)
            module.build(root, commit, path)
            original = path.read_bytes()
            other = Path(folder) / 'second.zip'
            module.build(root, commit, other)
            self.assertEqual(original, other.read_bytes())
            with self.assertRaises(FileExistsError):
                module.build(root, commit, path)
            self.assertEqual(path.read_bytes(), original)

    def test_ordinary_start_card_separates_setup_resume_and_storage_limits(self):
        from zipfile import ZipFile
        with tempfile.TemporaryDirectory() as folder:
            module, root, commit, path = self.bundle(folder)
            module.build(root, commit, path)
            with ZipFile(path) as archive:
                text = archive.read('START_HERE.txt').decode()
        for text_part in ('ordinary_synthetic_demo --help', 'setup --with-local-catalog --with-local-resource-approval',
                          'serve --state-dir', '--local-demo-config', 'pgserver==0.1.4',
                          '不再setup', '同一源码内容', '不能称永久持久化', '未从解压包实际初始化'):
            self.assertIn(text_part, text)
        self.assertNotIn('当前沙箱浏览器拒绝', text)


if __name__=='__main__':unittest.main(verbosity=2)
