from .business_frontier_types import BusinessFrontierFence,request as frontier_request
"""Internal synthetic offers; never grants or external fulfillment."""
from typing import Literal
from uuid import UUID, uuid4
from pydantic import BaseModel, ConfigDict, Field, field_validator
from psycopg.types.json import Jsonb
from . import preparation as prep, executor_receipts as receipts
from .store import Store, Denied, Conflict, digest

SCOPE = 'SYNTHETIC_INTERNAL_DISPATCH_ONLY'


class Offer(BaseModel):
    expected_business_frontier: BusinessFrontierFence | None = None
    model_config = ConfigDict(extra='forbid', strict=True, str_strip_whitespace=True)
    expected_preparation_revision: int = Field(ge=1)
    expected_dispatch_revision: int = Field(ge=0, le=64)
    executor_id: str = Field(min_length=1, max_length=100)
    reason: str = Field(min_length=1, max_length=1000)
    recovery_receipt_step_id: UUID | None = Field(default=None, strict=False)


class Command(BaseModel):
    expected_business_frontier: BusinessFrontierFence | None = None
    model_config = ConfigDict(extra='forbid', strict=True, str_strip_whitespace=True)
    action: Literal['ACCEPT', 'DECLINE', 'WITHDRAW']
    expected_revision: int = Field(ge=1, le=64)
    reason: str = Field(min_length=1, max_length=1000)


class AcceptRecoverySelection(BaseModel):
    """Opaque original selection; it neither supplies authority nor replays a body."""
    model_config = ConfigDict(extra='forbid')
    preparation_id: UUID
    case_id: UUID
    run_id: UUID
    offer_id: UUID
    expected_revision: int = Field(ge=1, le=63)
    preparation_revision: int = Field(ge=1, le=64)

    @field_validator('expected_revision','preparation_revision',mode='before')
    @classmethod
    def exact_revision(cls,value):
        if type(value) is int:return value
        if type(value) is str and value.isascii() and value.isdecimal() and str(int(value))==value:return int(value)
        raise ValueError('exact integer revision required')


class Reassign(BaseModel):
    expected_business_frontier: BusinessFrontierFence | None = None
    model_config = ConfigDict(extra='forbid', strict=True, str_strip_whitespace=True)
    expected_preparation_revision: int = Field(ge=1, le=64)
    expected_dispatch_revision: int = Field(ge=1, le=62)
    predecessor_offer_id: UUID = Field(strict=False)
    predecessor_receipt_step_id: UUID = Field(strict=False)
    expected_receipt_revision: int = Field(ge=1, le=64)
    executor_id: str = Field(min_length=1, max_length=100)
    reason: str = Field(min_length=1, max_length=1000)


def _typed_fields_equal(actual, expected):
    # JSON booleans and floating-point numbers cannot prove integer revisions.
    return all(type(actual.get(k)) is type(v) and actual.get(k) == v for k,v in expected.items())


def _handoff_enabled(store, c):
    from .isolated_local_execution import provider
    return type(store) is Store and provider(store) is None and \
        not any(getattr(store,name,None) is not None for name in (
            '_isolated_run_access','_isolated_local_execution','_isolated_execution_preview',
            '_isolated_resource_execution_preview','_isolated_dispatch_execution_preview',
            '_isolated_receipt_execution_preview','_isolated_lifecycle_execution_preview')) and \
        c.execute('SELECT max(version) v FROM schema_version').fetchone()['v'] in (29,30,31,32) and \
        bool(c.execute('SELECT 1 FROM schema_version WHERE version=29').fetchone())


def _handoff_predecessor(store, c, parent, root, *, write=False, accepting=False):
    if not root or not _handoff_enabled(store, c) or root['revision'] > (63 if accepting else 62):
        return None
    current=c.execute('SELECT state FROM service_dispatch_offers WHERE id=%s',
                      (root['current_offer_id'],)).fetchone()
    if not current or current['state'] not in (('OFFERED',) if accepting else ('ACCEPTED','DECLINED','WITHDRAWN')):
        return None
    accepted=_latest_accepted(c,root)
    if not accepted or not _fresh(parent,accepted,c,store):return None
    acceptance=dict(dispatch_id=str(root['id']),offer_id=str(accepted['id']),
                    receipt_step_id=str(accepted['receipt_step_id']),revision=accepted['acceptance_revision'],
                    action='ACCEPT',state='ACCEPTED',actor_id=accepted['executor_id'],executor_id=accepted['executor_id'])
    if not _typed_fields_equal(accepted['acceptance_payload'],acceptance):return None
    step=receipts._locked(c,accepted['receipt_step_id'],write=write)
    fields=('run_id','case_id','owner_id','park_id','org_id','service_id','service_version')
    if (not step or step['namespace']!='SYNTHETIC' or step['state']!='AWAITING_RECEIPT'
        or step['current_receipt_id'] is not None or step['preparation_id']!=parent['id']
        or any(step[k]!=parent[k] for k in fields)
        or step['executor_id']!=accepted['executor_id']
        or step['preparation_revision']!=accepted['preparation_revision']
        or step['preparation_sha256']!=accepted['preparation_sha256']
        or c.execute('SELECT 1 FROM service_step_receipts WHERE step_id=%s LIMIT 1',
                     (step['id'],)).fetchone()
        or c.execute("SELECT 1 FROM service_receipt_events WHERE step_id=%s AND action<>'CREATE' LIMIT 1",
                     (step['id'],)).fetchone()):return None
    return accepted,step


def _handoff_binding(parent, accepted, step):
    return dict(handoff_kind='PENDING_MANUAL_RECEIPT',predecessor_offer_id=str(accepted['id']),
                predecessor_receipt_step_id=str(step['id']),predecessor_executor_id=accepted['executor_id'],
                predecessor_receipt_revision=step['revision'],
                previous_preparation_revision=accepted['preparation_revision'],
                previous_preparation_sha256=accepted['preparation_sha256'],
                accepted_preparation_revision=parent['revision'],
                accepted_preparation_sha256=parent['review_sha256'])


def _auth(store, c, token):
    c.execute("SET LOCAL lock_timeout='3s'")
    p = store.auth(c, token, lock=True)
    if p['role'] not in ('enterprise_operator', 'park_specialist', 'service_executor'):
        raise Denied('internal dispatch role required')
    store.check_capability(c, p, 'READ')
    return p


def _parent(store, c, p, id, write=False):
    # Reviewers use their existing preparation assignment, not Run assignment.
    from .case_step_assignments import refuse_legacy
    if p['role'] != 'service_executor':
        row=prep.scoped(store, c, p, id, write=write)
        refuse_legacy(c,id)
        return row
    row = c.execute('SELECT * FROM preparations WHERE id=%s AND park_id=%s AND org_id=%s ' +
                    ('FOR UPDATE' if write else 'FOR SHARE'), (id, p['park_id'], p['org_id'])).fetchone()
    if not row: raise Denied('dispatch unavailable')
    refuse_legacy(c,id)
    store.scoped_run(c, p, row['run_id'])
    if not c.execute('SELECT 1 FROM service_dispatch_offers o JOIN service_dispatches d ON d.id=o.dispatch_id WHERE d.preparation_id=%s AND o.executor_id=%s', (id, p['id'])).fetchone():
        raise Denied('own offered dispatch required')
    return row


def _root(c, parent, write=False):
    return c.execute('SELECT * FROM service_dispatches WHERE preparation_id=%s ' +
                     ('FOR UPDATE' if write else 'FOR SHARE'), (parent['id'],)).fetchone()


def _own_offer(c, p, root):
    if p['role'] != 'service_executor':
        return c.execute('SELECT * FROM service_dispatch_offers WHERE id=%s', (root['current_offer_id'],)).fetchone()
    return c.execute('SELECT o.* FROM service_dispatch_offers o JOIN service_dispatch_events e ON e.offer_id=o.id WHERE o.dispatch_id=%s AND o.executor_id=%s ORDER BY e.revision DESC LIMIT 1', (root['id'], p['id'])).fetchone()


def _fresh(parent, offer,c=None,store=None):
    return parent['state'] == 'LOCAL_CONFIRMED' and parent['revision'] == offer['preparation_revision'] and parent['review_sha256'] == offer['preparation_sha256'] and (c is None or receipts.material_current(c,parent,store))


def _latest_accepted(c,root):
    row=c.execute("""SELECT o.*,e.revision AS acceptance_revision,e.actor_id AS acceptance_actor,
      e.payload AS acceptance_payload FROM service_dispatch_offers o JOIN service_dispatch_events e
      ON e.offer_id=o.id AND e.dispatch_id=o.dispatch_id AND e.action='ACCEPT'
      WHERE o.dispatch_id=%s AND o.state='ACCEPTED' ORDER BY e.revision DESC LIMIT 1""",(root['id'],)).fetchone()
    if not row:return None
    expected=dict(dispatch_id=str(root['id']),offer_id=str(row['id']),receipt_step_id=str(row['receipt_step_id']),
                  revision=row['acceptance_revision'],action='ACCEPT',state='ACCEPTED',
                  actor_id=row['executor_id'],executor_id=row['executor_id'])
    if row['acceptance_actor']!=row['executor_id'] or row['acceptance_revision']>root['revision'] or any(row['acceptance_payload'].get(k)!=v for k,v in expected.items()):return None
    return row


def _recovery(c,parent,root,store=None):
    """Latest actual acceptance is the immutable predecessor of a newer preparation."""
    if not root or not receipts.material_current(c,parent,store):return None
    current=c.execute('SELECT state FROM service_dispatch_offers WHERE id=%s',(root['current_offer_id'],)).fetchone()
    if not current or current['state'] not in ('ACCEPTED','DECLINED','WITHDRAWN'):return None
    accepted=_latest_accepted(c,root)
    if not accepted or accepted['preparation_revision']>=parent['revision']:return None
    step=c.execute('SELECT * FROM service_receipt_steps WHERE id=%s AND preparation_id=%s',
                   (accepted['receipt_step_id'],parent['id'])).fetchone()
    if not step or step['executor_id']!=accepted['executor_id'] or step['preparation_revision']!=accepted['preparation_revision'] or step['preparation_sha256']!=accepted['preparation_sha256']:return None
    if c.execute('SELECT 1 FROM service_receipt_steps WHERE preparation_id=%s AND preparation_revision=%s',(parent['id'],parent['revision'])).fetchone():return None
    return accepted


def _recovery_flags(c,p,parent,root,store=None):
    predecessor=_recovery(c,parent,root,store)
    return dict(can_reoffer=bool(predecessor and p['role']=='park_specialist' and root['revision']<63),
                reoffer_kind='NEW_MATERIAL_ACCEPTANCE_REQUIRED' if predecessor else None,
                recovery_receipt_step_id=predecessor['receipt_step_id'] if predecessor else None)


def _party(store, c, parent, id, capability):
    store.lock_principal(c, id)
    p = c.execute('SELECT * FROM principals WHERE id=%s AND active AND park_id=%s AND org_id=%s', (id, parent['park_id'], parent['org_id'])).fetchone()
    if not p: raise Denied('current preparation participant required')
    prep.grant(store, c, p, capability)
    if capability == 'PREPARE': store.check_capability(c, p, 'EXECUTE')
    return p


def _key(c, p, key):
    c.execute('SELECT pg_advisory_xact_lock(hashtextextended(%s,0))', ('service-dispatch-key:' + p['id'] + ':' + key,))


def _replay(c, p, key, fp, root):
    old = c.execute('SELECT * FROM service_dispatch_events WHERE actor_id=%s AND request_key=%s', (p['id'], key)).fetchone()
    if old:
        if old['fingerprint'] != fp or not root or old['dispatch_id'] != root['id']:
            raise Conflict('dispatch request key fingerprint mismatch')
        return old['payload']


def _event(c, p, root, offer, key, fp, action, reason, **extra):
    payload = dict(dispatch_id=str(root['id']), offer_id=str(offer['id']), revision=root['revision'],
                   action=action, state=offer['state'], actor_id=p['id'], executor_id=offer['executor_id'],
                   reason=reason, receipt_step_id=str(offer['receipt_step_id']) if offer['receipt_step_id'] else None, **extra)
    from .business_frontier import event_fence
    payload.update(event_fence(c))
    event_id=uuid4()
    c.execute('INSERT INTO service_dispatch_events(id,dispatch_id,offer_id,actor_id,request_key,fingerprint,revision,action,payload) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)',
              (event_id, root['id'], offer['id'], p['id'], key, fp, root['revision'], action, Jsonb(payload)))
    from .controlled_plans import invalidate
    invalidate(c,c.execute('SELECT preparation_id FROM service_dispatches WHERE id=%s',(root['id'],)).fetchone()['preparation_id'],3)
    from .dispatch_notices import enqueue
    enqueue(c,event_id)
    return payload


def _view(c, p, parent, root, event=None,store=None):
    cancelled=prep.case_cancelled(c,parent);blocked=prep.case_write_blocked(c,parent)
    from .controlled_plans import _hash
    result = dict(scope=SCOPE, actor_ref=_hash(dict(actor_id=p['id'])), case_id=parent['case_id'], run_id=parent['run_id'], case_cancelled=cancelled, case_reconciling=prep.case_state(c,parent)=='RECONCILING', case_write_blocked=blocked, can_accept=False, role=p['role'], preparation_id=parent['id'], goal=parent['goal'],
                  service_id=parent['service_id'], service_version=parent['service_version'],
                  preparation_revision=parent['revision'], dispatch_id=root['id'] if root else None,
                  revision=root['revision'] if root else 0, current_offer=None, offers=[], history=[], event=event,
                  dependency='CURRENT', receipt_step_id=None, is_current_offer=False,
                  current_receipt_step_id=None,can_reoffer=False,reoffer_kind=None,recovery_receipt_step_id=None,
                  qualification='NOT_EVALUATED', external_acceptance='NOT_SUBMITTED',
                  offline_fulfillment='NO_EVIDENCE', case_goal_completed=False)
    from .business_frontier import view as frontier_view
    result.update(frontier_view(c,parent))
    if not root: return result
    offer = _own_offer(c, p, root)
    if not offer: raise Denied('own offered dispatch required')
    executor = p['role'] == 'service_executor'
    clause = ' AND o.executor_id=%s' if executor else ''
    params = (root['id'], p['id']) if executor else (root['id'],)
    result.update(current_offer=offer, is_current_offer=offer['id'] == root['current_offer_id'],
                  dependency='CURRENT' if _fresh(parent, offer,c,store) else 'DEPENDENCY_CHANGED',
                  receipt_step_id=offer['receipt_step_id'],
                  offers=c.execute('SELECT o.* FROM service_dispatch_offers o WHERE o.dispatch_id=%s' + clause + ' ORDER BY o.created_at,o.id', params).fetchall(),
                  history=c.execute('SELECT e.revision,e.action,e.payload,e.created_at FROM service_dispatch_events e JOIN service_dispatch_offers o ON o.id=e.offer_id WHERE e.dispatch_id=%s' + clause + ' ORDER BY e.revision', params).fetchall())
    # Executor projection continues to expose only its own offer lineage.
    if offer['id']==root['current_offer_id']:
        result.update(current_receipt_step_id=offer['receipt_step_id'] if offer['state']=='ACCEPTED' else None,
                      **_recovery_flags(c,p,parent,root,store))
    if blocked:result.update(can_reoffer=False,reoffer_kind=None)
    else:result['can_accept']=executor and result['is_current_offer'] and offer['state']=='OFFERED' and result['dependency']=='CURRENT'
    return result


@receipts.bounded
def catalog(store, token, id):
    with store.connect() as c:
        p = _auth(store, c, token)
        if p['role'] != 'park_specialist': raise Denied('assigned preparation reviewer required')
        parent = _parent(store, c, p, id)
        root = _root(c, parent)
        existing = bool(c.execute('SELECT 1 FROM service_receipt_steps WHERE preparation_id=%s', (id,)).fetchone())
        rows = store.assigned_executors(c,parent['run_id'],p['park_id'],p['org_id'])
        current = _own_offer(c, p, root) if root else None
        recovery=_recovery(c,parent,root,store)
        limited = bool(root and root['revision'] >= 63)
        ready = receipts.material_current(c,parent,store) and not limited and ((not existing and (not current or current['state'] in ('DECLINED', 'WITHDRAWN'))) or bool(recovery))
        if recovery:rows=[r for r in rows if r['id']==recovery['executor_id']]
        handoff=_handoff_predecessor(store,c,parent,root)
        handoff_rows=[r for r in rows if handoff and r['id']!=handoff[0]['executor_id']]
        from .business_frontier import view as frontier_view
        return dict(**frontier_view(c,parent),scope=SCOPE, preparation_revision=parent['revision'], dispatch_revision=root['revision'] if root else 0,
                    case_cancelled=prep.case_cancelled(c,parent),case_reconciling=prep.case_state(c,parent)=='RECONCILING',case_write_blocked=prep.case_write_blocked(c,parent),ready=ready and bool(rows) and not prep.case_write_blocked(c,parent), executors=rows, has_receipt_step=existing, history_limit_reached=limited,
                    can_reassign=bool(handoff_rows) and not prep.case_write_blocked(c,parent),reassignment_executors=handoff_rows,
                    reassignment_actor_id=p['id'],
                    reassignment_predecessor=_handoff_binding(parent,*handoff) if handoff else None,
                    **_recovery_flags(c,p,parent,root,store))


@receipts.bounded
def read_preparation(store, token, id):
    with store.connect() as c:
        p = _auth(store, c, token); parent = _parent(store, c, p, id)
        return _view(c, p, parent, _root(c, parent),store=store)


@receipts.bounded
def read(store, token, id):
    with store.connect() as c:
        p = _auth(store, c, token)
        root = c.execute('SELECT preparation_id FROM service_dispatches WHERE id=%s', (id,)).fetchone()
        if not root: raise Denied('dispatch unavailable')
        parent = _parent(store, c, p, root['preparation_id'])
        return _view(c, p, parent, _root(c, parent),store=store)


@receipts.bounded
def recover_accept(store, token, id, key, selection):
    """Read the existing atomic ACCEPT/receipt CREATE proof, under live access.

    Absence is inconclusive: an original request may still arrive later. The
    response deliberately carries no writable view, saved reason or approval.
    """
    if type(selection) is not AcceptRecoverySelection:raise Denied('typed original selection required')
    from .controlled_plans import _hash
    with store.connect() as c:
        p=_auth(store,c,token)
        if p['role']!='service_executor':raise Denied('own dispatch decision role required')
        # Same actor/key lock ordering as the original command, without any DML.
        _key(c,p,key)
        base=c.execute('SELECT preparation_id FROM service_dispatches WHERE id=%s',(id,)).fetchone()
        if not base:raise Denied('dispatch unavailable')
        parent=_parent(store,c,p,base['preparation_id']);root=_root(c,parent)
        if (parent['id']!=selection.preparation_id or parent['case_id']!=selection.case_id
                or parent['run_id']!=selection.run_id):raise Denied('dispatch unavailable')
        own=c.execute('SELECT * FROM service_dispatch_offers WHERE id=%s AND dispatch_id=%s AND executor_id=%s',
                      (selection.offer_id,id,p['id'])).fetchone()
        if not own:raise Denied('dispatch unavailable')
        if own['preparation_revision']!=selection.preparation_revision:
            raise Conflict('original acceptance selection mismatch')
        offered=c.execute("SELECT revision FROM service_dispatch_events WHERE dispatch_id=%s AND offer_id=%s AND action IN ('OFFER','REOFFER') ORDER BY revision LIMIT 1",(id,own['id'])).fetchone()
        if not offered or offered['revision']!=selection.expected_revision:
            raise Conflict('original acceptance selection mismatch')
        old=c.execute('SELECT * FROM service_dispatch_events WHERE actor_id=%s AND request_key=%s',
                      (p['id'],key)).fetchone()
        event=None
        if old:
            expected=dict(dispatch_id=str(id),offer_id=str(own['id']),revision=selection.expected_revision+1,
                          action='ACCEPT',state='ACCEPTED',actor_id=p['id'],executor_id=p['id'],
                          receipt_step_id=str(own['receipt_step_id']))
            if (old['dispatch_id']!=id or old['offer_id']!=own['id'] or old['action']!='ACCEPT'
                    or old['revision']!=selection.expected_revision+1 or old['revision']>root['revision']
                    or own['state']!='ACCEPTED' or not own['receipt_step_id']
                    or not _typed_fields_equal(old['payload'],expected)):
                raise Conflict('original acceptance proof mismatch')
            step=c.execute('SELECT * FROM service_receipt_steps WHERE id=%s',(own['receipt_step_id'],)).fetchone()
            created=c.execute('SELECT * FROM service_receipt_events WHERE actor_id=%s AND request_key=%s',
                              (p['id'],'dispatch-accept:'+str(own['id']))).fetchone()
            fields=('run_id','case_id','owner_id','park_id','org_id','service_id','service_version')
            if (not step or any(step[k]!=parent[k] for k in fields) or step['namespace']!='SYNTHETIC'
                    or step['preparation_id']!=parent['id'] or step['executor_id']!=p['id']
                    or step['preparation_revision']!=own['preparation_revision']
                    or step['preparation_sha256']!=own['preparation_sha256']
                    or not created or created['step_id']!=step['id'] or created['action']!='CREATE'
                    or created['revision']!=1 or created['fingerprint']!=old['fingerprint']
                    or not _typed_fields_equal(created['payload'],dict(step_id=str(step['id']),revision=1,
                        state='AWAITING_RECEIPT',action='CREATE',actor_id=p['id'],scope=receipts.SCOPE,
                        dispatch_id=str(id),offer_id=str(own['id'])))):
                raise Conflict('original acceptance receipt proof mismatch')
            event=dict(id=str(old['id']),action='ACCEPT',revision=old['revision'],receipt_step_id=str(step['id']))
        # A lock wait must never revive a revoked current assignment or READ.
        _auth(store,c,token);store.scoped_run(c,p,parent['run_id'])
        return dict(scope=SCOPE,actor_ref=_hash(dict(actor_id=p['id'])),dispatch_id=str(id),
                    **{k:str(getattr(selection,k)) for k in ('preparation_id','case_id','run_id','offer_id')},
                    expected_revision=selection.expected_revision,preparation_revision=selection.preparation_revision,
                    request_key=key,status='COMMITTED' if old else 'NOT_OBSERVED',event=event,
                    historical_only=True,read_only=True,automatically_replayed=False,case_goal_completed=False)


@receipts.bounded
def reassign(store, token, id, key, data):
    if type(data) is not Reassign:raise Denied('typed reassignment required')
    fp=digest(prep.canonical(dict(dispatch_id=str(id),type='PENDING_RECEIPT_HANDOFF',
                                 **frontier_request(data))))
    with store.connect() as c:
        p=_auth(store,c,token)
        if p['role']!='park_specialist':raise Denied('assigned preparation reviewer required')
        _key(c,p,key)
        base=c.execute('SELECT preparation_id FROM service_dispatches WHERE id=%s',(id,)).fetchone()
        if not base:raise Denied('dispatch unavailable')
        parent=_parent(store,c,p,base['preparation_id'],write=True);root=_root(c,parent,write=True)
        prep.case_write_guard(c,parent)
        if not _handoff_enabled(store,c):raise Conflict('manual receipt handoff is not installed or available')
        receipts._executor(store,c,data.executor_id,parent['run_id'])
        _party(store,c,parent,parent['owner_id'],'PREPARE')
        old=_replay(c,p,key,fp,root)
        if old:return _view(c,p,parent,root,old,store)
        from .business_frontier import check_fence
        check_fence(c,parent,data)
        from .controlled_plans import gate
        gate(store,c,parent,2)
        if parent['revision']!=data.expected_preparation_revision or root['revision']!=data.expected_dispatch_revision:
            raise Conflict('current preparation and dispatch revisions required')
        predecessor=_handoff_predecessor(store,c,parent,root,write=True)
        if not predecessor:raise Conflict('current accepted manual step without any receipt required')
        accepted,step=predecessor
        if (accepted['id']!=data.predecessor_offer_id or step['id']!=data.predecessor_receipt_step_id
            or step['revision']!=data.expected_receipt_revision or accepted['executor_id']==data.executor_id):
            raise Conflict('exact pending predecessor and different executor required')
        oid=uuid4()
        root=c.execute('UPDATE service_dispatches SET revision=revision+1,current_offer_id=%s WHERE id=%s RETURNING *',
                       (oid,root['id'])).fetchone()
        offered=c.execute("INSERT INTO service_dispatch_offers(id,dispatch_id,executor_id,preparation_revision,preparation_sha256,reason,state) VALUES(%s,%s,%s,%s,%s,%s,'OFFERED') RETURNING *",
                          (oid,root['id'],data.executor_id,parent['revision'],parent['review_sha256'],data.reason)).fetchone()
        return _view(c,p,parent,root,_event(c,p,root,offered,key,fp,'REOFFER',data.reason,
                                          **_handoff_binding(parent,accepted,step)),store)


@receipts.bounded
def recover_reassignment(store, token, id, key):
    with store.connect() as c:
        p=_auth(store,c,token)
        if p['role']!='park_specialist':raise Denied('assigned preparation reviewer required')
        base=c.execute('SELECT preparation_id FROM service_dispatches WHERE id=%s',(id,)).fetchone()
        if not base:raise Denied('dispatch unavailable')
        parent=_parent(store,c,p,base['preparation_id']);root=_root(c,parent)
        old=c.execute('SELECT * FROM service_dispatch_events WHERE actor_id=%s AND request_key=%s',(p['id'],key)).fetchone()
        if old and (old['dispatch_id']!=root['id'] or old['action']!='REOFFER'
                    or old['payload'].get('handoff_kind')!='PENDING_MANUAL_RECEIPT'):
            raise Conflict('original reassignment request scope mismatch')
        return dict(scope=SCOPE,dispatch_id=str(id),preparation_id=str(parent['id']),request_key=key,
                    status='COMMITTED' if old else 'NOT_OBSERVED',event=old['payload'] if old else None,
                    historical_only=True,automatically_replayed=False)


@receipts.bounded
def offer(store, token, id, key, data):
    body=frontier_request(data)
    if data.recovery_receipt_step_id is None:body.pop('recovery_receipt_step_id')
    fp = digest(prep.canonical(dict(preparation_id=str(id), **body)))
    with store.connect() as c:
        p = _auth(store, c, token)
        if p['role'] != 'park_specialist': raise Denied('assigned preparation reviewer required')
        _key(c, p, key); parent = _parent(store, c, p, id, write=True); root = _root(c, parent, write=True)
        prep.case_write_guard(c,parent)
        receipts._executor(store, c, data.executor_id, parent['run_id'])
        _party(store, c, parent, parent['owner_id'], 'PREPARE')
        old = _replay(c, p, key, fp, root)
        if old: return _view(c, p, parent, root, old,store)
        from .business_frontier import check_fence
        check_fence(c,parent,data)
        from .controlled_plans import gate
        gate(store,c,parent,2)
        if not receipts.material_current(c,parent,store) or parent['revision'] != data.expected_preparation_revision:
            raise Conflict('current locally confirmed preparation required')
        if (root['revision'] if root else 0) != data.expected_dispatch_revision:
            raise Conflict('stale dispatch revision; refresh required')
        existing=bool(c.execute('SELECT 1 FROM service_receipt_steps WHERE preparation_id=%s', (id,)).fetchone())
        recovery=_recovery(c,parent,root,store)
        if existing:
            if not recovery or data.recovery_receipt_step_id!=recovery['receipt_step_id']:
                raise Conflict('new preparation acceptance requires the exact historical receipt generation')
            if data.executor_id!=recovery['executor_id']:raise Conflict('new material acceptance must retain the original executor')
        elif data.recovery_receipt_step_id is not None:raise Conflict('no accepted receipt generation to recover')
        if root:
            current = _own_offer(c, p, root)
            if current['state'] not in ('DECLINED', 'WITHDRAWN') and not recovery: raise Conflict('resolve current offer before reoffering')
            if root['revision'] >= 63: raise Conflict('dispatch history limit reached')
        oid = uuid4(); action = 'REOFFER' if root else 'OFFER'
        if root:
            root = c.execute('UPDATE service_dispatches SET revision=revision+1,current_offer_id=%s WHERE id=%s RETURNING *', (oid, root['id'])).fetchone()
        else:
            root = c.execute('INSERT INTO service_dispatches(id,preparation_id,revision,current_offer_id) VALUES(%s,%s,1,%s) RETURNING *', (uuid4(), id, oid)).fetchone()
        offered = c.execute("INSERT INTO service_dispatch_offers(id,dispatch_id,executor_id,preparation_revision,preparation_sha256,reason,state) VALUES(%s,%s,%s,%s,%s,%s,'OFFERED') RETURNING *", (oid, root['id'], data.executor_id, parent['revision'], parent['review_sha256'], data.reason)).fetchone()
        lineage=dict(predecessor_offer_id=str(recovery['id']),predecessor_receipt_step_id=str(recovery['receipt_step_id']),
                     previous_preparation_revision=recovery['preparation_revision'],previous_preparation_sha256=recovery['preparation_sha256'],
                     accepted_preparation_revision=parent['revision'],accepted_preparation_sha256=parent['review_sha256']) if recovery else {}
        return _view(c, p, parent, root, _event(c, p, root, offered, key, fp, action, data.reason,**lineage),store)


@receipts.bounded
def command(store, token, id, key, data):
    fp = digest(prep.canonical(dict(dispatch_id=str(id), **frontier_request(data))))
    with store.connect() as c:
        p = _auth(store, c, token)
        if p['role'] != ('park_specialist' if data.action == 'WITHDRAW' else 'service_executor'):
            raise Denied('own dispatch decision role required')
        _key(c, p, key)
        base = c.execute('SELECT preparation_id FROM service_dispatches WHERE id=%s', (id,)).fetchone()
        if not base: raise Denied('dispatch unavailable')
        parent = _parent(store, c, p, base['preparation_id'], write=True); root = _root(c, parent, write=True)
        prep.case_write_guard(c,parent)
        own = _own_offer(c, p, root)
        if data.action == 'ACCEPT':
            _party(store, c, parent, parent['reviewer_id'], 'REVIEW_ASSIGNED')
            _party(store, c, parent, parent['owner_id'], 'PREPARE')
        old = _replay(c, p, key, fp, root)
        if old: return _view(c, p, parent, root, old,store)
        from .business_frontier import check_fence
        check_fence(c,parent,data)
        if own['id'] != root['current_offer_id'] or own['state'] != 'OFFERED':
            raise Conflict('current offered dispatch required')
        if root['revision'] != data.expected_revision: raise Conflict('stale dispatch revision; refresh required')
        if root['revision'] >= 64: raise Conflict('dispatch history limit reached')
        # Decline/withdraw may resolve stale offers without reviving revoked grants.
        step_id = None
        lineage = {}
        if data.action == 'ACCEPT':
            from .controlled_plans import gate
            gate(store,c,parent,2)
            if not _fresh(parent, own,c,store): raise Conflict('dispatch preparation dependency changed')
            existing=c.execute('SELECT 1 FROM service_receipt_steps WHERE preparation_id=%s', (parent['id'],)).fetchone()
            offered_event=c.execute("SELECT payload FROM service_dispatch_events WHERE offer_id=%s AND action IN ('OFFER','REOFFER') ORDER BY revision LIMIT 1",(own['id'],)).fetchone()
            predecessor_id=(offered_event['payload'].get('predecessor_receipt_step_id') if offered_event else None)
            if existing:
                handoff=offered_event and offered_event['payload'].get('handoff_kind')=='PENDING_MANUAL_RECEIPT'
                if handoff:
                    predecessor=_handoff_predecessor(store,c,parent,root,write=True,accepting=True)
                    if not predecessor:raise Conflict('pending manual receipt predecessor is no longer current')
                    accepted,previous_step=predecessor
                    expected=_handoff_binding(parent,accepted,previous_step)
                    if (not _typed_fields_equal(offered_event['payload'],expected)
                        or accepted['executor_id']==p['id']):
                        raise Conflict('exact reassignment offer lineage required')
                    lineage=expected
                else:
                    predecessor=c.execute('SELECT * FROM service_receipt_steps WHERE id=%s AND preparation_id=%s',(predecessor_id,parent['id'])).fetchone() if predecessor_id else None
                    payload=offered_event['payload'] if offered_event else {}
                    predecessor_offer=_latest_accepted(c,root)
                    expected=dict(predecessor_offer_id=str(predecessor_offer['id']),
                                  predecessor_receipt_step_id=str(predecessor_offer['receipt_step_id']),
                                  previous_preparation_revision=predecessor_offer['preparation_revision'],
                                  previous_preparation_sha256=predecessor_offer['preparation_sha256'],
                                  accepted_preparation_revision=own['preparation_revision'],
                                  accepted_preparation_sha256=own['preparation_sha256']) if predecessor_offer else {}
                    if not predecessor or not predecessor_offer or not expected or any(payload.get(k)!=v for k,v in expected.items()) or predecessor_offer['executor_id']!=p['id'] or predecessor['executor_id']!=p['id'] or predecessor['preparation_revision']!=predecessor_offer['preparation_revision'] or predecessor['preparation_sha256']!=predecessor_offer['preparation_sha256'] or predecessor['preparation_revision']>=parent['revision']:
                        raise Conflict('preparation already has receipt step; explicit new material offer required')
                    if c.execute('SELECT 1 FROM service_receipt_steps WHERE preparation_id=%s AND preparation_revision=%s',(parent['id'],parent['revision'])).fetchone():
                        raise Conflict('current preparation already has receipt generation')
                    lineage=expected
            step = receipts._insert_step(c, parent, p['id']); step_id = step['id']
            receipts._event(c, p, step, 'dispatch-accept:' + str(own['id']), fp, 'CREATE', dispatch_id=str(root['id']), offer_id=str(own['id']), reason=data.reason,**lineage)
        states = {'ACCEPT':'ACCEPTED', 'DECLINE':'DECLINED', 'WITHDRAW':'WITHDRAWN'}
        own = c.execute('UPDATE service_dispatch_offers SET state=%s,receipt_step_id=%s WHERE id=%s RETURNING *', (states[data.action], step_id, own['id'])).fetchone()
        root = c.execute('UPDATE service_dispatches SET revision=revision+1 WHERE id=%s RETURNING *', (id,)).fetchone()
        return _view(c, p, parent, root, _event(c, p, root, own, key, fp, data.action, data.reason,**lineage),store)


@receipts.bounded
def list_items(store, token):
    with store.connect() as c:
        p = _auth(store, c, token)
        if p['role'] != 'service_executor': prep.grant(store, c, p, 'PREPARE' if p['role']=='enterprise_operator' else 'REVIEW_ASSIGNED')
        column = 'owner_id' if p['role']=='enterprise_operator' else 'reviewer_id'
        condition = 'p.' + column + '=%s' if p['role']!='service_executor' else "EXISTS(SELECT 1 FROM service_dispatch_offers o WHERE o.dispatch_id=d.id AND o.executor_id=%s) AND EXISTS(SELECT 1 FROM run_assignments a WHERE a.run_id=p.run_id AND a.principal_id=%s AND a.park_id=p.park_id AND a.org_id=p.org_id AND a.active)"
        params = (p['park_id'],p['org_id'],p['id'],p['id']) if p['role']=='service_executor' else (p['park_id'],p['org_id'],p['id'])
        rows = c.execute('SELECT d.id,p.id preparation_id,p.goal,p.run_id FROM service_dispatches d JOIN preparations p ON p.id=d.preparation_id WHERE p.park_id=%s AND p.org_id=%s AND ' + condition + ' ORDER BY d.created_at DESC,d.id DESC LIMIT 101', params).fetchall()
        raw_more=len(rows)>100
        scanned=len(rows)
        if p['role']=='service_executor':
            rows=[r for r in rows if store.assignment_allowed(c,p,r['run_id'])]
        from .case_step_assignments import legacy_rows
        rows=legacy_rows(c,rows,'preparation_id')
        for row in rows:
            row.pop('run_id',None)
        return dict(scope=SCOPE, role=p['role'], items=rows[:100], has_older_records=raw_more, access_filtered=scanned-len(rows))
